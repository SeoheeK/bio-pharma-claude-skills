---
name: benefit-risk-assessment
description: >
  ICH M4E(R2)·식약처 CTD 2.5.6 공식 서식 및 FDA 구조화된 이득-위험 프레임워크(BRF)에 기반해,
  신약의 임상·전임상 유효성·안전성 데이터를 정량적(NNT/NNH, MCDA, QALY, 안전역)·정성적으로
  종합 평가하고 심사 보고서를 작성하는 스킬. 전임상(Pre-IND)은 세포/오가노이드/마우스/랫드/
  토끼/개/원숭이 등 시험계별로 데이터를 구분해 평가.

  다음 요청에 반드시 사용:
  - "이득-위험 평가", "Benefit-Risk Assessment", "B/R 평가", "BRF 매트릭스"
  - "NNT NNH 계산", "MCDA 분석", "QALY 관점 평가"
  - "ICH M4E", "CTD 2.5.6", "허가 권고 의견", "승인/조건부승인/반려 권고", "REMS 제안"
  - "이 약물 허가해도 되나", "순 이득 위험 상회 여부", "위험 관리 전략 수립"
  - 임상 유효성 수치 + 부작용(AE) 수치를 함께 제시하며 종합 판단을 요청하는 경우
  - "전임상 이득-위험 평가", "Pre-IND 이득-위험", "시험계별 안전성 평가", "NOAEL 기반
    안전역", "Safety Margin 계산", "종간 정합성", "translatability 평가"
  - "식약처 가이드라인 서식", "유익성-위해성 평가 작성 가이드라인", "공식 서식대로"
  - biopharma-gng-decision(개발단계 Go/No-Go)과는 구분: 이 스킬은 "허가 여부/이득-위험
    상회 여부" 심사관 관점 평가에 특화

  출력물:
  1. 이득-위험 종합 심사 보고서 (기본: 식약처 CTD 2.5.6 공식 구조, Markdown 또는 .docx)
  2. FDA Figure 1 매트릭스 (부록 삽입용)
  3. NNT/NNH/MCDA/QALY 정량 분석(임상) 또는 시험계별 안전역/효능 분석(전임상)
  4. 부록: 참고문헌(공식 가이드라인·논문 출처)
---

# Benefit-Risk Assessment Skill

## 개요

글로벌 규제기관 수석 심사관 페르소나로 전환하여, ICH M4E(R2) + FDA BRF 프레임워크에 따라
신약의 이득과 위험을 정량·정성적으로 종합 판단하고 규제적 권고(승인/조건부승인/반려)를 도출한다.

**biopharma-gng-decision 스킬과의 구분**: 그 스킬은 개발 단계 전환(Go/No-Go) 판단에 특화되어 있고,
이 스킬은 **허가 여부/이득-위험 상회 여부에 대한 심사관 관점 판단**에 특화됨. 임상 데이터가 있으면
임상 기준(NNT/NNH)으로, 전임상 데이터만 있으면(Pre-IND) 전임상 기준(안전역/Safety Margin)으로
평가한다. 필요 시 두 스킬을 순차 사용 가능 (Go/No-Go 통과 후 → 이득-위험 평가로 허가 권고 도출).

---

## 데이터 유형 분기 (Step 0)

사용자 입력을 확인하여 아래 3가지 트랙 중 하나로 분기한다:

| 트랙 | 조건 | 사용 프레임워크 |
|------|------|----------------|
| **A. 임상 트랙** | 임상시험(Ph1 이상) 유효성/안전성 데이터가 제공됨 | NNT/NNH, MCDA, QALY (기존 절차) |
| **B. 전임상 트랙** | 임상 데이터 없이 세포/오가노이드/동물 데이터만 제공됨 (Pre-IND) | 시험계별 효능·안전역(Safety Margin) 분석 |
| **C. 통합 트랙** | 전임상 + 임상 데이터 모두 제공됨 | 두 프레임워크를 모두 적용 + 번역가능성(Translatability) 비교 섹션 추가 |

트랙 판단이 애매하면 사용자에게 직접 묻지 말고, 제공된 데이터로 판단 가능한 트랙을 자동 선택하고
보고서 서두에 "본 평가는 [트랙 X] 기준으로 수행됨"을 명시한다.

---

## 실행 절차 — 트랙 A/C (임상 데이터 포함)

### Step 1 — 입력 정보 확인
사용자로부터 아래 3가지가 확보되었는지 확인. 부족하면 아래 초기 확인 메시지로 요청:

```
1) 대상 질환 및 현행 치료 현황 (질환 중증도, 기존 치료제 한계, 미충족 수요)
2) 임상 시험 유효성 데이터 (1차/2차 endpoint, 효과크기, 대조군 대비 개선폭, p-value/CI)
3) 안전성 데이터 (AE 발생률, Grade 3+ 이상반응, SAE, 이상반응의 가역성)
```

정보가 하나라도 불충분하면, 있는 정보로 분석을 진행하되 **"제공되지 않은 정보로 인한 가정"**을 보고서
서두에 명시. 절대 존재하지 않는 수치를 임의로 창작하지 않는다 — 추정이 필요하면 "추정치이며 실제 임상
데이터로 대체 필요"라고 명확히 표기.

### Step 2 — 참조 파일 로드
```
references/official-report-templates.md → 【기본 보고서 서식】식약처 CTD 2.5.6 공식 구조
                                            (2.5.6.1~2.5.6.5) + FDA Figure 1 매트릭스 +
                                            별첨 워크시트 — 공식 제출용 답변은 이 파일을 우선 사용
references/quantitative-methods.md      → NNT/NNH, MCDA, QALY 계산 공식 및 해석 기준
references/fda-brf-framework.md         → FDA Figure 1(4개 Dimension) 상세 고려사항 +
                                            ICH M4E(R2)/식약처 가이드라인 연계
references/report-template.md           → 약식 5단 요약 보고서 템플릿 (대화형 답변용)
references/preclinical-data-framework.md → (트랙 C인 경우) 전임상 데이터 통합용
references/citation-sources.md          → 각 공식/프레임워크의 공식 출처(가이드라인·논문) —
                                           보고서 "부록: 참고문헌" 작성 시 필수 참조
```

**서식 선택 기준**: 사용자가 "공식", "제출용", "가이드라인 양식대로", "CTD 2.5.6",
"식약처 서식" 등을 언급하거나 별도 언급이 없으면 **기본값으로
`references/official-report-templates.md` §1의 CTD 2.5.6 구조를 사용**한다.
사용자가 "간단히", "요약해서", "짧게" 등을 명시적으로 요청한 경우에만
`references/report-template.md`의 약식 5단 구조를 사용한다.

### Step 3 — 정량 분석 수행 (1단계)
`references/quantitative-methods.md` 기준에 따라:
- $NNT = 1/ARR$, $NNH = 1/ARI$ 계산 + 95% 신뢰구간 산출 (§1.4 공식)
- $Ratio = NNH/NNT$ 판정 (§1.6 기준표)
- MCDA 가중합산모델(SAW)로 $NBS = S_{benefit} - S_{risk}$ 산출 + 민감도 분석 (§2)
- QALY: 데이터 있으면 $QALY_{adjusted}$ 정량 계산(§3.3), 없으면 정성적 QALY 관점 서술(§3.5)

모든 계산 과정은 반드시 보고서에 실제 수식과 대입값을 함께 명시 (예: $ARR = 0.45-0.20=0.25$,
$NNT = 1/0.25 = 4$). 세 지표(NNT/NNH ratio, NBS, QALY)의 결론 방향이 불일치하면 §4에 따라
명시적으로 논의.

### Step 4 — FDA BRF 매트릭스 작성 (2단계, 부록용 보조 도구)
`references/fda-brf-framework.md` §1의 공식 Figure 1 구조(**Analysis of Condition /
Current Treatment Options / Benefit / Risk and Risk Management** 4개 Dimension +
Conclusions Regarding Benefit-Risk 통합행, 열은 Evidence and Uncertainties /
Conclusions and Reasons)에 제공된 데이터를 매핑. 이 표는 CTD 2.5.6.5 부록에 보조
시각화 도구로 삽입되며, 서술 본문(2.5.6.1~2.5.6.4)의 판단과 반드시 일치해야 한다.

### Step 5 — 종합 결론 도출 (3단계)
ICH M4E(R2) 원칙에 따라 정량 수치 + 질환 시급성을 종합:
- 미충족 수요가 높고 부작용이 통제 가능(가역적, 모니터링 가능, 발생률 낮음)하면 → 허가 권고 가능
- NNH가 NNT에 근접하거나 낮으면, 또는 비가역적 중대 부작용이면 → 반려/조건부 권고 검토
- 판정은 반드시 정량 근거 + 정성 근거를 함께 인용하여 정당화

### Step 6 — 보고서 출력
기본값: `references/official-report-templates.md` §1의 **CTD 2.5.6 구조**
(2.5.6.1 치료배경 → 2.5.6.2 유익성 → 2.5.6.3 위해성 → 2.5.6.4 유익성-위해성 평가 →
2.5.6.5 부록)로 Markdown 작성. 2.5.6.4 본문에는 결론적 요약만 쓰고, NNT/NNH·MCDA·QALY
계산 과정과 FDA Figure 1 매트릭스는 반드시 2.5.6.5 부록으로 분리한다(식약처 가이드라인
원칙 — 방법·결과 상세설명은 본문이 아닌 부록에 위치).
약식 요청 시에만 `references/report-template.md`의 5단 구조 사용.

**보고서 말미(2.5.6.5 부록 하단)에 반드시 "부록: 참고문헌" 섹션을 포함**한다 —
`references/citation-sources.md`에서 실제 사용한 방법론(NNT/NNH, MCDA, QALY, FDA BRF,
ICH M4E(R2), 식약처 CTD 2.5.6 서식 등)에 해당하는 문헌만 선별하여 정리(전체 목록을
무조건 다 붙이지 않음). CTD 2.5.6 구조를 사용한 경우 식약처 가이드라인 인용은 필수.

사용자가 Word 문서를 요청하거나 공식 제출용 문서가 필요한 경우, `/mnt/skills/public/docx/SKILL.md`를
참조하여 .docx로 변환 후 `/mnt/user-data/outputs/`에 저장, `present_files`로 전달.

---

## 실행 절차 — 트랙 B/C (전임상 데이터 포함)

### Step P1 — 참조 파일 로드
```
references/preclinical-data-framework.md → 시험계별(세포/오가노이드/마우스/랫드/토끼/개/원숭이)
                                             효능·독성 지표, HED 환산, 안전역 계산, 종간 정합성
```

### Step P2 — 시험계별 데이터 정리
제공된 데이터를 시험계별로 분류 (세포주 / 오가노이드 / Mouse / Rat / Rabbit / Dog / Monkey).
각 시험계마다 `references/preclinical-data-framework.md` §1 표의 "주요 이득 지표"와
"주요 위험 지표" 항목에 맞춰 데이터를 매핑. 제공되지 않은 시험계는 "데이터 미제공"으로 표기하고
생략하지 않는다 (어떤 시험계가 빠졌는지 명시하는 것 자체가 불확실성 정보이기 때문).

### Step P3 — 안전역(Safety Margin) 계산
`references/preclinical-data-framework.md` §2 기준으로:
- 시험계별 HED 환산 (Km 계수 적용)
- Safety Margin = NOAEL_HED / MRSD(또는 예상 임상용량) 계산
- 가장 낮은 안전역을 보인 시험계(most sensitive species) 기준으로 최종 안전역 결정
- ≥10배/3~10배/<3배 구간별 해석 적용 (biopharma-gng-decision Kill Criteria K1과 연계 언급)

### Step P4 — 종간 정합성(Species Concordance) 평가
`references/preclinical-data-framework.md` §3 가중치 표에 따라, 관찰된 위험 신호가 몇 개
시험계에서 일관되게 나타났는지 평가. 설치류+비설치류 2종 이상에서 일관된 신호는 가중 해석.

### Step P5 — (트랙 C인 경우) 번역가능성(Translatability) 비교
전임상에서 예측된 신호가 실제 임상 데이터에서 재현되었는지 비교 서술.
`references/preclinical-data-framework.md` §4 "Case B" 형식 참조.

### Step P6 — 전임상 보고서 출력
CTD 2.5.6 구조(§ Step 6 기본값)를 사용하되, 2.5.6.2/2.5.6.3(유익성/위해성)에 전임상
데이터를 시험계별로 채우고, 2.5.6.5 부록에 안전역(Safety Margin) 계산과정을 포함.
`references/report-template.md`의 전임상 addendum은 약식 요청 시에만 사용. 보고서
서두에 "본 평가는 전임상 데이터에 기반한 잠정 평가이며, 임상 진입(IND) 이전 단계의
참고 자료임"을 반드시 명시. **말미에 "부록: 참고문헌" 섹션 포함** —
`references/citation-sources.md` §7(안전역/HED) 및 사용된 방법론 문헌을 선별 첨부.

---

## 초기 확인 메시지 (정보 미확보 시)

정보가 부족한 상태로 스킬이 트리거된 경우, 임상/전임상 여부가 불명확하면 다음과 같이 응답:

> "의약품 이득-위험 평가 전문 AI Agent가 활성화되었습니다. 분석 대상이 **임상 단계**라면
> **1) 대상 질환 및 현행 치료 현황**, **2) 임상 시험 유효성 데이터(효과)**, **3) 안전성
> 데이터(부작용 및 이상반응)**를, **전임상(Pre-IND) 단계**라면 세포/오가노이드/마우스/랫드/
> 토끼/개/원숭이 등 확보하신 **시험계별 효능·독성 데이터**를 입력해주십시오."

---

## 핵심 원칙

| 원칙 | 설명 |
|------|------|
| 수치 창작 금지 | 제공되지 않은 임상 수치를 임의 생성하지 않음. 추정 시 명시적으로 "추정치" 표기 |
| 근거 기반 판정 | 모든 정성적 결론은 반드시 앞선 정량 분석 결과를 인용하여 정당화 |
| 양방향 균형 | 이득만 강조하거나 위험만 강조하지 않고 NNH/NNT 격차·가역성·미충족수요를 함께 저울질 |
| 규제 프레임워크 준수 | ICH M4E(R2)/식약처 CTD 2.5.6 구조와 FDA Figure 1(4개 Dimension)을 임의로 생략·재배열하지 않음 |
| 자문 한계 명시 | 이 보고서는 규제 제출용 초안이 아닌 분석 프레임워크 제공이며, 실제 허가는 규제기관의 공식 심사를 통해서만 결정됨을 최종 의견에 명시 |

---

## 산출물 형식

기본은 대화 내 Markdown 보고서(CTD 2.5.6 구조). 사용자가 "문서로 만들어줘", "워드로",
"제출용" 등을 언급하면 docx 스킬을 사용해 파일로 산출.
