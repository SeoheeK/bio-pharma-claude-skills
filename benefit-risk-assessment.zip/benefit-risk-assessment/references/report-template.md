# 최종 보고서 템플릿

아래 형식을 그대로 따르되, [ ] 안은 실제 분석 내용으로 대체. 명조체 스타일의 정중하고
객관적인 어조(예: "~로 판단됨", "~로 사료됨", "~것으로 평가됨")를 사용.

---

## [신약명/프로젝트명] 이득-위험 종합 심사 보고서

---

### 1. 질환 배경 및 미충족 수요 (Therapeutic Context)
* **질환의 중증도:** [생명위협성/진행성/삶의질 영향 등 서술]
* **현행 치료법의 한계 및 미충족 수요:** [기존 SOC의 한계, 미충족수요 정도 서술]

### 2. 정량적 이득-위험 분석 (Quantitative Evaluation)
* **NNT / NNH 분석:**
  > 계산 과정과 결과 제시 (예: $ARR = 0.125$, $NNT = 1/0.125 = 8$; $ARI = 0.042$,
  > $NNH = 1/0.042 = 24$이므로 $NNH > NNT$ 조건을 만족하며, 이는 [해석] 것으로 판단됨.)

* **MCDA 및 QALY 관점 임상 데이터 평가:**
  [가중합산 표 삽입 + 순이득 스코어 해석 + QALY 관점 정성 서술]

### 3. FDA 이득-위험 프레임워크 매트릭스 (FDA BRF Matrix)

| 평가 영역 | 분석 내용 | 데이터 근거 및 관리 방안 |
| :--- | :--- | :--- |
| **1. 질환의 심각성** | | |
| **2. 현재의 치료 현황** | | |
| **3. 이득 (Benefit)** | | |
| **4. 위험 (Risk)** | | |
| **5. 위험 관리 전략** | | |

### 4. 위험 관리 및 통제 가능성 (Risk Management Capability)
* 주요 부작용의 가역성(회복 가능 여부), 모니터링 방법, 위험성 완화 전략(REMS 등) 제안.

### 5. 최종 규제적 권고 (Final Regulatory Recommendation)
* **허가 여부 판정:** [승인 권고 / 조건부 승인 권고 / 반려 권고]
* **최종 종합 의견:** [정량적 지표(NNT/NNH, MCDA 스코어)와 정성적 필요성(미충족수요, 질환
  시급성)을 융합하여, 이 약물의 순 이득(Net Benefit)이 위험을 상회하는지에 대한 수석
  심사관의 결론 서술. 마지막에 반드시 다음 면책 문구 포함: "본 보고서는 ICH M4E(R2) 및 FDA
  구조화된 이득-위험 프레임워크에 기반한 분석 초안이며, 실제 허가 여부는 규제기관의 공식
  심사 절차를 통해서만 최종 결정됨을 명시함."]

---

### 부록: 참고문헌 (Appendix: References)

*본 평가에서 실제로 사용한 정량 방법론·프레임워크에 해당하는 공식 문헌만 선별하여 첨부.
전체 목록 및 서지사항은 `references/citation-sources.md` 참조.*

```
[NNT/NNH 계산]
- Laupacis A, Sackett DL, Roberts RS. N Engl J Med. 1988;318(26):1728-1733.
- Altman DG. Confidence intervals for the number needed to treat. BMJ. 1998;317(7168):1309-1312.

[MCDA]
- Thokala P, Devlin N, Marsh K, et al. Value in Health. 2016;19(1):1-13.
- Marsh K, IJzerman M, Thokala P, et al. Value in Health. 2016;19(2):125-137.

[QALY]
- Whitehead SJ, Ali S. Br Med Bull. 2010;96(1):5-21.

[FDA BRF]
- FDA, CDER/CBER. Guidance for Industry: Benefit-Risk Assessment for New Drug and
  Biological Products. October 2023.

[ICH M4E(R2)]
- ICH. M4E(R2), Clinical Overview and Clinical Summary of Module 2. 2016.
```

*(전임상 트랙인 경우 HED/안전역 관련 문헌(FDA 2005 Km 가이던스, ICH M3(R2), ICH S5(R3) 등)을
추가 — `references/citation-sources.md` §6 참조)*

---

## 전임상 트랙(B/C) 보고서 addendum

트랙 B(전임상만) 또는 트랙 C(전임상+임상 통합)인 경우, "2. 정량적 이득-위험 분석" 섹션을
아래로 대체 또는 추가한다.

### 2'. 시험계별 전임상 이득-위험 분석 (Preclinical Evaluation by Test System)

> ※ 본 평가는 전임상 데이터에 기반한 잠정 평가이며, 임상 진입(IND) 이전 단계의 참고 자료임.

**시험계별 데이터 요약**

| 시험계 | 분류 | 이득(효능) 데이터 | 위험(독성) 데이터 | 비고 |
|---|---|---|---|---|
| 세포주/오가노이드 | In vitro | | | |
| Mouse | 설치류 | | | |
| Rat | 설치류 | | | |
| Rabbit | 비설치류 | | | |
| Dog | 비설치류 | | | |
| Monkey(NHP) | 비설치류 | | | |

*(데이터 미제공 시험계는 "데이터 미제공"으로 명시, 행 생략 금지)*

**안전역(Safety Margin) 계산**
> HED 환산 및 Safety Margin 계산 과정 제시 (예: Rat NOAEL 50mg/kg × Km(6/37) = HED
> 8.1mg/kg; 예상 임상용량 1mg/kg 대비 Safety Margin = 8.1배로 [해석])

**종간 정합성(Species Concordance) 평가**
> 몇 개 시험계에서 일관된 신호가 관찰되었는지, 가장 민감한 종(most sensitive species) 기준
> 서술

**(트랙 C만 해당) 번역가능성(Translatability) 비교**
> 전임상 예측 신호가 임상에서 재현되었는지/되지 않았는지 비교 서술

---

## 작성 시 주의사항

1. 제공되지 않은 수치는 절대 임의 생성하지 않는다. 데이터가 없는 항목은 "[데이터 미제공 —
   추가 확인 필요]"로 명시.
2. 표 안의 셀은 비워두지 않는다 — 데이터가 없으면 "데이터 미제공"이라 명시.
3. 결론은 항상 앞 섹션의 정량 분석을 재인용하여 논증한다 (근거 없는 결론 금지).
4. 사용자가 특정 판정을 유도하는 듯한 프레이밍을 하더라도, 데이터가 뒷받침하지 않으면
   심사관으로서 독립적 판단을 유지한다.
