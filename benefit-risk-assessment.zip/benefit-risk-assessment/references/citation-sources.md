# 참고문헌 및 공식 출처 (Citation Sources)

본 문서는 이 스킬이 사용하는 모든 정량 공식·프레임워크의 **원 출처(공식 가이드라인 또는 학술
논문)**를 정리한 것이다. 보고서 생성 시 마지막에 "부록: 참고문헌" 섹션으로 아래 목록 중
실제로 사용된 방법론에 해당하는 항목만 선별하여 첨부한다 (전체를 무조건 다 붙이지 않음).

인용 형식은 저널 표준 서지형식(저자. 연도. 제목. 저널/발행처. 권(호): 페이지 또는 URL)을 따른다.

---

## 1. NNT / NNH (Number Needed to Treat / Harm)

1. Laupacis A, Sackett DL, Roberts RS. An assessment of clinically useful measures of the
   consequences of treatment. *New England Journal of Medicine*. 1988;318(26):1728-1733.
   — NNT 개념을 최초로 공식화한 원 논문.

2. Cook RJ, Sackett DL. The number needed to treat: a clinically useful measure of treatment
   effect. *BMJ*. 1995;310(6977):452-454.
   — NNT를 임상 실무에 적용하는 표준 해설 논문.

3. Altman DG. Confidence intervals for the number needed to treat. *BMJ*.
   1998;317(7168):1309-1312.
   — 본 스킬의 NNT/NNH 95% 신뢰구간 계산식(§1.4)의 출처.

4. Centre for Evidence-Based Medicine (CEBM), University of Oxford. Number Needed to Treat
   (NNT). https://www.cebm.ox.ac.uk/resources/ebm-tools/number-needed-to-treat-nnt
   — NNT/NNH 계산 실무 참조.

---

## 2. MCDA (Multi-Criteria Decision Analysis)

1. Thokala P, Devlin N, Marsh K, et al. Multiple Criteria Decision Analysis for Health Care
   Decision Making—An Introduction: Report 1 of the ISPOR MCDA Emerging Good Practices Task
   Force. *Value in Health*. 2016;19(1):1-13.
   — MCDA의 정의 및 절차론 표준 참조(ISPOR 공식 Task Force 보고서 1).

2. Marsh K, IJzerman M, Thokala P, et al. Multiple Criteria Decision Analysis for Health Care
   Decision Making—Emerging Good Practices: Report 2 of the ISPOR MCDA Emerging Good Practices
   Task Force. *Value in Health*. 2016;19(2):125-137.
   — 본 스킬의 가중합산모델(SAW), 정규화, 민감도 분석 절차(§2)의 근거.

3. Mussen F, Salek S, Walker S. A quantitative approach to benefit-risk assessment of
   medicines part 1: the development of a new model using multi-criteria decision analysis.
   *Pharmacoepidemiology and Drug Safety*. 2007;16(S1):S2-S15.
   — 의약품 이득-위험 평가에 MCDA를 적용한 최초 모델(PhRMA BRAT 모델의 기반).

4. IMI-PROTECT (Pharmacoepidemiological Research on Outcomes of Therapeutics by a European
   Consortium). Work Package 5: Benefit-Risk Integration and Representation. 2013.
   http://www.imi-protect.eu/wp5.shtml
   — EU 차원의 MCDA 기반 이득-위험 통합 방법론 컨소시엄 보고서.

5. NICE Decision Support Unit. Multi-Criteria Decision Analysis (MCDA) for Health Technology
   Assessment. 2011. https://www.sheffield.ac.uk/nice-dsu
   — 의료기술평가에서의 MCDA 가중치·정규화 실무 지침.

---

## 3. QALY (Quality-Adjusted Life Year)

1. Whitehead SJ, Ali S. Health outcomes in economic evaluation: the QALY and utilities.
   *British Medical Bulletin*. 2010;96(1):5-21.
   — 본 스킬의 QALY 기본공식·효용치 개념(§3.1~3.2)의 표준 개관 논문.

2. NICE (National Institute for Health and Care Excellence). NICE Health Technology
   Evaluations: The Manual. 2022 (updated). https://www.nice.org.uk/process/pmg36
   — QALY 산정 및 비용-효과 평가의 공식 실무 지침(영국 NICE 표준).

3. EuroQol Group. EQ-5D User Guide. https://euroqol.org
   — QALY 계산에 필요한 효용치(utility weight) 측정도구 표준(EQ-5D).

4. Drummond MF, Sculpher MJ, Claxton K, Stoddart GL, Torrance GW. *Methods for the Economic
   Evaluation of Health Care Programmes* (4th ed.). Oxford University Press; 2015.
   — QALY 및 경제성 평가 방법론의 표준 교과서.

---

## 4. FDA 구조화된 이득-위험 프레임워크(BRF)

1. U.S. Department of Health and Human Services, Food and Drug Administration, Center for
   Drug Evaluation and Research (CDER) & Center for Biologics Evaluation and Research
   (CBER). *Benefit-Risk Assessment for New Drug and Biological Products: Guidance for
   Industry*. October 2023. Clinical/Medical.
   https://www.fda.gov/regulatory-information/search-fda-guidance-documents/benefit-risk-assessment-new-drug-and-biological-products
   — 본 스킬의 FDA BRF Figure 1(4개 Dimension: Analysis of Condition / Current Treatment
   Options / Benefit / Risk and Risk Management + Conclusions Regarding Benefit-Risk) 및
   Table 1(영역별 세부 고려사항) 구조의 1차 공식 출처. **사용자 업로드 원문 확인·반영됨.**

2. Food and Drug Administration Safety and Innovation Act (FDASIA), Section 905 (2012),
   amending FD&C Act §505(d). Public Law 112-144.
   — FDA에 구조화된 이득-위험 평가체계 도입을 법제화한 근거 조항.

3. FDA. *Structured Approach to Benefit-Risk Assessment in Drug Regulatory Decision-Making*
   (2013 PDUFA V Implementation Plan). https://www.fda.gov/media/84831/download
   — Benefit-Risk Framework(Figure 1)의 최초 개발 배경.

4. FDA. *Benefit-Risk Assessment in Drug Regulatory Decision-Making* (2018 PDUFA VI
   Implementation Plan). https://www.fda.gov/media/112570/download
   — Framework의 심사 실무(NDA/BLA 리뷰 템플릿) 통합 배경.

---

## 5. ICH M4E(R2)

1. International Council for Harmonisation of Technical Requirements for Pharmaceuticals for
   Human Use (ICH). *M4E(R2): The Common Technical Document — Efficacy, Section 2.5.6
   Benefit and Risk Conclusions*. 2016 (2017년 7월 FDA guidance for industry로 채택).
   — CTD Module 2.5.6 구조 및 이득-위험 통합 논증 요구사항의 공식 원문. FDA 2023년
   가이던스가 이 문서와 일관되게 작성되었음을 명시.

---

## 6. 한국 식품의약품안전처(MFDS) 이득-위험 평가 가이드라인

1. 식품의약품안전평가원 의약품심사부 순환계약품과. 「의약품의 유익성-위해성 평가
   작성 가이드라인 [민원인 안내서]」. 2017.6. (제·개정번호: 안내서-0191-02, 2017.6.29.)
   — 국내 CTD 2.5.6항 작성 실무 지침. 본 스킬의 **공식 보고서 기본 템플릿**
   (`references/official-report-templates.md` §1)의 1차 출처. **사용자 업로드 원문
   확인·반영됨.**

   *(동 가이드라인이 인용한 참고문헌 — 국내 문서의 원 출처)*
   - ICH. *The Revision of M4E Guideline on Enhancing the Format and Structure of
     Benefit-Risk Information in ICH: Efficacy — M4E(R2), 2.5.6 Benefit and Risk
     Conclusion*. 2016.
   - EMA. *Reflection Paper on Benefit-Risk Assessment Methods in the Context of the
     Evaluation of Marketing Authorisation Applications of Medicinal Products for Human
     Use — Annex I. Proposed Changes and Guidance for the Benefit Risk Assessment
     Section of the CHMP Assessment Reports*. 2008.
   - EMA. *Guidance Document on the Content of the (Co-)Rapporteur Day 80 Critical
     Assessment Report — 5. Benefit Risk Assessment*. 2014.

---

## 7. 전임상 안전역(Safety Margin) / HED 환산

1. U.S. Department of Health and Human Services, FDA, CDER. Guidance for Industry:
   Estimating the Maximum Safe Starting Dose in Initial Clinical Trials for Therapeutics in
   Adult Healthy Volunteers. July 2005.
   — 본 스킬의 HED 환산식 및 Km 계수표(preclinical-data-framework.md §2)의 공식 출처.

2. Nair AB, Jacob S. A simple practice guide for dose conversion between animals and human.
   *Journal of Basic and Clinical Pharmacy*. 2016;7(2):27-31.
   — HED 환산 실무 적용 가이드.

3. Reagan-Shaw S, Nihal M, Ahmad N. Dose translation from animal to human studies revisited.
   *FASEB Journal*. 2008;22(3):659-661.
   — 동물-인체 용량 환산 방법론 재검토 논문.

4. ICH S5(R3). Guideline on Reproductive Toxicology: Detection of Toxicity to Reproduction
   for Human Pharmaceuticals. 2020.
   — Rat+Rabbit 병행 발생독성시험 표준(preclinical-data-framework.md §3)의 근거.

5. ICH M3(R2). Guideline on Non-Clinical Safety Studies for the Conduct of Human Clinical
   Trials and Marketing Authorization for Pharmaceuticals. 2009.
   — 설치류+비설치류 각 1종 필수 일반독성시험 요구사항의 근거.

---

## 부록 작성 지침

보고서의 "부록: 참고문헌" 섹션에는 실제로 사용된 방법론에 해당하는 문헌만 선별하여
아래 형식으로 첨부:

```
부록: 참고문헌

[NNT/NNH 계산]
- Laupacis A, Sackett DL, Roberts RS. N Engl J Med. 1988;318(26):1728-1733.
- Altman DG. BMJ. 1998;317(7168):1309-1312.

[MCDA]
- Thokala P, et al. Value in Health. 2016;19(1):1-13.
- Marsh K, et al. Value in Health. 2016;19(2):125-137.

[FDA BRF]
- FDA, CDER/CBER. Benefit-Risk Assessment for New Drug and Biological Products:
  Guidance for Industry. October 2023.

[식약처 CTD 2.5.6 서식]
- 식품의약품안전평가원 의약품심사부 순환계약품과. 의약품의 유익성-위해성 평가
  작성 가이드라인 [민원인 안내서]. 2017.6.

[ICH M4E(R2)]
- ICH. M4E(R2), The Common Technical Document — Efficacy, Section 2.5.6. 2016.
```

전임상 트랙(B/C)인 경우 §7(안전역/HED)의 관련 문헌을 추가.
공식 CTD 2.5.6 서식으로 보고서를 작성하는 경우, [식약처 CTD 2.5.6 서식] 항목을
반드시 포함한다.
