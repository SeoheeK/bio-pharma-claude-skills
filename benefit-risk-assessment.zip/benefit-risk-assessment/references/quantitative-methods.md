# 정량적 이득-위험 분석 방법론

본 문서는 이득-위험 평가에 사용되는 3대 정량 모델(NNT/NNH, MCDA, QALY)의 **수식·유도 과정·
신뢰구간 계산·worked example**을 포함한다. 보고서 작성 시 아래 수식을 반드시 실제 대입 계산
형태로 제시하고, 기호만 나열하지 않는다.

---

## 1. NNT / NNH 계산

### 1.1 기초 변수 정의

| 기호 | 의미 |
|---|---|
| $CER$ | Control Event Rate (대조군 이벤트 발생률) |
| $EER$ | Experimental Event Rate (치료군 이벤트 발생률) |
| $n_c, n_e$ | 대조군/치료군 표본수 |
| $x_c, x_e$ | 대조군/치료군 이벤트 발생 건수 |

$$CER = x_c / n_c, \quad EER = x_e / n_e$$

### 1.2 NNT (이득 이벤트 기준)

이득 이벤트(예: 반응, 관해, 생존)는 치료군에서 더 많이 발생해야 하므로:

$$ARR = EER_{benefit} - CER_{benefit}$$
$$NNT = \dfrac{1}{ARR} = \dfrac{1}{EER_{benefit} - CER_{benefit}}$$

**Worked example**
- 대조군 반응률 $CER = 20\% = 0.20$, 치료군 반응률 $EER = 45\% = 0.45$
- $ARR = 0.45 - 0.20 = 0.25$
- $NNT = 1/0.25 = 4$ → 4명을 치료하면 1명에게서 추가적 반응(관해)을 얻음

### 1.3 NNH (위해 이벤트 기준)

위해 이벤트(AE, SAE)는 치료군에서 더 많이 발생하므로:

$$ARI = EER_{harm} - CER_{harm}$$
$$NNH = \dfrac{1}{ARI} = \dfrac{1}{EER_{harm} - CER_{harm}}$$

**Worked example**
- 대조군 Grade 3+ AE 발생률 $CER = 8\% = 0.08$, 치료군 $EER = 22\% = 0.22$
- $ARI = 0.22 - 0.08 = 0.14$
- $NNH = 1/0.14 = 7.14 \approx 7$ → 약 7명을 치료하면 1명에게서 추가적 중대 이상반응 발생

### 1.4 95% 신뢰구간

$ARR$(또는 $ARI$)의 표준오차:

$$SE(ARR) = \sqrt{\dfrac{CER(1-CER)}{n_c} + \dfrac{EER(1-EER)}{n_e}}$$

$$95\%\ CI\ of\ ARR = ARR \pm 1.96 \times SE(ARR)$$

$NNT$의 신뢰구간은 $ARR$의 CI 상/하한을 각각 역수 취하여 계산 (구간이 0을 포함하면 NNT의
CI는 발산하므로 "통계적으로 유의하지 않음"으로 보고):

$$NNT_{lower} = 1/ARR_{upper}, \quad NNT_{upper} = 1/ARR_{lower}$$

**Worked example (§1.2 연속)**
- $n_c = n_e = 100$
- $SE(ARR) = \sqrt{\dfrac{0.20 \times 0.80}{100} + \dfrac{0.45 \times 0.55}{100}} = \sqrt{0.0016+0.002475} = \sqrt{0.004075} \approx 0.0638$
- $95\%\ CI = 0.25 \pm 1.96 \times 0.0638 = 0.25 \pm 0.125 = [0.125,\ 0.375]$
- $NNT\ 95\%\ CI = [1/0.375,\ 1/0.125] = [2.67,\ 8.0]$ → "4 (95% CI 2.7–8.0)"로 보고

### 1.5 RR, RRR, OR와의 관계 (보조 지표)

$$RR\ (Relative\ Risk) = \dfrac{EER}{CER}$$
$$RRR\ (Relative\ Risk\ Reduction) = 1 - RR = \dfrac{CER-EER}{CER}\ (해로운\ 이벤트\ 기준)$$
$$OR\ (Odds\ Ratio) = \dfrac{EER/(1-EER)}{CER/(1-CER)}$$

RR/RRR/OR은 상대적 크기만 나타내고 기저발생률(baseline risk)을 반영하지 못하므로, **최종
판정은 반드시 절대위험 기반인 NNT/NNH를 사용**하고 RR/OR은 문헌 비교 시 보조지표로만 인용.

### 1.6 NNT/NNH 격차 판정

$$Ratio = \dfrac{NNH}{NNT}$$

| $Ratio$ | 해석 |
|---|---|
| $\geq 3$ | 이득이 위험을 상당히 상회 → 허가 우호적 신호 |
| $1 < Ratio < 3$ | 이득이 위험을 상회하나 위험관리 전략 필수 |
| $\leq 1$ | 위험이 이득에 근접·상회 → 반려 또는 서브그룹 제한 검토 |

**주의**: 이벤트 심각도가 다르면(예: NNT의 이벤트="생존", NNH의 이벤트="경미한 발진") 단순
비율 비교는 무의미 — 반드시 §2 MCDA 단계에서 심각도 가중치로 보정.

---

## 2. MCDA (다기준 의사결정분석) — 가중합산모델(Weighted Sum Model, SAW)

### 2.1 정규화(Normalization)

이득 기준(값이 클수록 좋음)의 정규화 값 함수:

$$v_i(x_i) = \dfrac{x_i - x_{worst}}{x_{best} - x_{worst}}$$

위험 기준(값이 클수록 나쁨)은 방향을 반전:

$$v_i(x_i) = \dfrac{x_{worst} - x_i}{x_{worst} - x_{best}} = 1 - \dfrac{x_i - x_{best}}{x_{worst}-x_{best}}$$

정규화 후 모든 $v_i \in [0, 1]$ (또는 0~10 스케일 사용 시 $v_i \times 10$).

### 2.2 가중치 정규화

$$\sum_{i=1}^{n} w_i = 1, \quad w_i \geq 0$$

### 2.3 가중합산 점수

이득 기준 총점:
$$S_{benefit} = \sum_{i \in Benefit} w_i \cdot v_i(x_i)$$

위험 기준 총점:
$$S_{risk} = \sum_{j \in Risk} w_j \cdot v_j(x_j)$$

**순이득 스코어(Net Benefit Score)**:
$$NBS = S_{benefit} - S_{risk}$$

$NBS > 0$이면 이득이 위험을 상회, $NBS \leq 0$이면 위험이 이득을 상회 또는 균형.

### 2.4 가중치 결정 기준 (질환 중증도별)

| 질환 중증도 | 유효성 가중치 합 $\sum w_{benefit}$ | 안전성 가중치 합 $\sum w_{risk}$ |
|------|------|------|
| 생명위협적 (말기암, 희귀 중증질환) | 60~70% | 30~40% |
| 중증 만성질환 (미충족수요 높음) | 50~60% | 40~50% |
| 경증~중등증 (대체 치료제 존재) | 30~40% | 60~70% |

### 2.5 Worked Example

전제: 생명위협적 질환, $\sum w_{benefit}=0.65$, $\sum w_{risk}=0.35$ (10점 만점 정규화 척도)

| 변수 | 유형 | 가중치 $w_i$ | 데이터 근거 | 정규화 점수 $v_i$ (0~10) | $w_i \times v_i$ |
|---|---|---|---|---|---|
| OS 개선 | 이득 | 0.35 | HR 0.65, p<0.01 | 8 | 2.80 |
| ORR 개선 | 이득 | 0.30 | 45% vs 20% | 7 | 2.10 |
| Grade 3+ AE | 위험 | 0.20 | 22% vs 8% | 6 (역방향 반영 후) | 1.20 |
| SAE | 위험 | 0.15 | 9% vs 3% | 5 | 0.75 |

$$S_{benefit} = 2.80 + 2.10 = 4.90 \ (/6.5 만점)$$
$$S_{risk} = 1.20 + 0.75 = 1.95\ (/3.5 만점)$$
$$NBS = 4.90 - 1.95 = 2.95 \ (>0 \Rightarrow \text{이득이 위험을 상회})$$

### 2.6 민감도 분석 (Sensitivity Analysis)

가중치 설정의 주관성을 검증하기 위해, 가중치를 ±10%p 범위에서 흔들어(swing weighting)
$NBS$ 부호가 바뀌는지 확인:

$$NBS_{sensitivity} = \sum w_i' \cdot v_i(x_i), \quad w_i' = w_i \pm \Delta$$

부호가 뒤집히지 않으면 "결론이 가중치 설정에 강건함(robust)"으로 보고서에 명시.

---

## 3. QALY 관점 평가

### 3.1 기본 공식

$$QALY = \sum_{t} u_t \times \Delta t_t$$

- $u_t \in [0,1]$: 시점 $t$ 구간의 건강 효용치(utility weight; 0=사망, 1=완전건강)
- $\Delta t_t$: 해당 구간의 기간(년)

### 3.2 증분 QALY (Incremental QALY)

$$\Delta QALY = QALY_{treatment} - QALY_{control}$$

### 3.3 부작용 보정 QALY (AE-adjusted QALY)

부작용으로 인한 효용치 손실을 반영:

$$QALY_{adjusted} = QALY_{gained} - \sum_{k} (d_k \times \Delta t_k)$$

- $d_k$: $k$번째 부작용으로 인한 효용치 감소분(disutility, 0~1)
- $\Delta t_k$: 해당 부작용 지속 기간(년)

### 3.4 Worked Example

- 치료군 OS 연장: 8개월 = 0.667년, 해당 기간 평균 효용치 $u=0.75$
  → $QALY_{gained} = 0.667 \times 0.75 = 0.50$
- Grade 3+ AE(예: 호중구감소증) 발생 기간 1.5개월 = 0.125년, disutility $d=0.30$
  → $QALY\ loss = 0.125 \times 0.30 = 0.0375$
- $QALY_{adjusted} = 0.50 - 0.0375 = 0.4625$

→ 부작용을 고려하더라도 순 QALY 이득이 양(+)으로 유지됨을 확인.

### 3.5 데이터 미비 시 정성적 대체 절차

효용치(EQ-5D, FACT 등) 데이터가 없는 경우, 정량 계산 대신 아래 3항목을 정성 서술:
1. 생명 연장 효과 (OS/PFS 개선 개월 수)
2. QoL 저하 요인 (기능적 손상, 입원 필요성, 일상활동 제한)
3. 순 편익 판단 (생명연장 대비 QoL 저하가 상회하는지 서술)

이 경우 보고서에 "정량 QALY 데이터 미제공으로 정성적 QALY 관점 평가로 대체함"을 명시.

---

## 4. 종합 정량 판정 흐름

```
NNT/NNH 계산 (+ 95% CI)
   ↓
NNH/NNT Ratio 판정
   ↓
MCDA 가중합산 (질환 중증도별 가중치, Net Benefit Score 산출)
   ↓
민감도 분석 (가중치 흔들림에 결론이 강건한지 확인)
   ↓
QALY 정량/정성 보정 (AE-adjusted QALY)
   ↓
정량 결론: "이득이 위험을 [상회/근접/하회]함" (NBS 부호 + QALY 부호 + NNH/NNT ratio 종합)
   ↓ (3단계 종합결론 섹션에서 질환 시급성·미충족수요와 결합)
```

세 지표(NNT/NNH ratio, NBS, QALY)의 방향이 서로 다르면(예: NNH/NNT는 우호적이나 QALY는
음수) 반드시 불일치를 보고서에 명시하고, 어느 지표에 더 높은 신뢰도를 부여하는지(대개
QALY는 대리 데이터 의존도가 높아 불확실성이 큼) 근거와 함께 서술.
