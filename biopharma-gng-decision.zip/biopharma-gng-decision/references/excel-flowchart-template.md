# 엑셀 템플릿 + 플로우차트 템플릿 (excel-flowchart-template.md)

---

# PART 1 — 엑셀 스코어카드 템플릿

## 워크북 시트 구성

```
wb.sheets:
  00_판정개요          ← 전체 게이트 판정 결과 요약
  G0_전임상→IND       ← 게이트별 상세 스코어카드
  G1_IND→Ph1
  G2_Ph1→Ph2
  G3_Ph2→Ph3          ← ⭐ 핵심 게이트
  G4_Ph3→NDA
  G5_시판→LCM
  Kill_Criteria        ← Kill Criteria 체크리스트
```

---

## 공통 스타일 함수 (biopharma-strategy-research 스킬과 동일 패턴)

```python
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

PALETTE = {
    "navy":   "1F3864", "blue":  "2E75B6", "mid":   "2F5597",
    "white":  "FFFFFF",
    "b1":     "EEF2FA", "b2":    "FFFFFF",
    "GO":     "C6EFCE", "CGO":   "FFEB9C", "NG":    "FFC7CE",
    "KILL":   "FF0000",
    "score_high":  "C6EFCE",  # 3~4점
    "score_mid":   "FFEB9C",  # 2점
    "score_low":   "FFC7CE",  # 0~1점
    "dim_colors": {
        "SCI": "D6E4F7", "CLN": "D9EAD3", "REG": "FFF2CC",
        "MKT": "FCE4D6", "CMC": "EAD1DC", "FIN": "D9D2E9",
    }
}
thin  = Side(border_style="thin",   color="BDD7EE")
thick = Side(border_style="medium", color="1F3864")

def bdr(c, s="thin"):
    sd = thin if s=="thin" else thick
    c.border = Border(left=sd, right=sd, top=sd, bottom=sd)

def fill(h): return PatternFill("solid", fgColor=h)
```

---

## 00_판정개요 시트 레이아웃

```
행 1:  타이틀 "Go/No-Go 의사결정 스코어카드 — [약물명] | [모달리티]"
행 2:  부제목 "생성일: YYYY-MM-DD | 기준: 6개 차원 × 3단계 판정"
행 4:  컬럼 헤더: [게이트 | 단계 전환 | 총점 | 판정 | Kill여부 | 핵심 이슈]
행 5~10: G0~G5 요약 행 (판정 결과 색상 자동 적용)
행 12: 판정 범례 (GO≥70 / CGO 50~69 / NG<50)
행 14: Kill Criteria 발동 여부 요약
```

---

## 게이트별 스코어카드 시트 레이아웃

```
컬럼 구조 (예: G3_Ph2→Ph3):
A: No.
B: 평가 축 (SCI/CLN/REG/MKT/CMC/FIN)
C: 항목명 (한글)
D: 항목명 (영문)
E: 점수 입력 (0~4) ← 데이터 유효성 검사 드롭다운
F: 최대점수 (4)
G: 점수/4 (달성률 %)
H: 근거 메모
```

```
하단 요약 섹션:
- 축별 평균 점수 (SCI, CLN, ...)
- 축별 가중치
- 축별 가중 점수
- 총점 (합산)
- 판정 셀 (GO/CGO/NG, 색상 자동)
- Kill Criteria 발동 여부
- 핵심 이슈 / 조건부 이행 사항
```

---

## 점수 셀 조건부 서식 (openpyxl 방식)

```python
def apply_score_color(ws, row, col, score: int):
    """점수에 따라 셀 배경색 적용"""
    c = ws.cell(row=row, column=col)
    if score >= 3:
        c.fill = fill("C6EFCE")   # 초록
        c.font = Font(name="Arial", size=10, bold=True, color="276221")
    elif score == 2:
        c.fill = fill("FFEB9C")   # 노랑
        c.font = Font(name="Arial", size=10, bold=True, color="9C6500")
    elif score <= 1:
        c.fill = fill("FFC7CE")   # 빨강
        c.font = Font(name="Arial", size=10, bold=True, color="9C0006")
```

---

## 판정 셀 생성

```python
def make_verdict_cell(ws, row, col, verdict: str):
    c = ws.cell(row=row, column=col)
    labels = {
        "GO":             ("✅ GO",             "C6EFCE", "276221"),
        "CONDITIONAL_GO": ("⚠️ CONDITIONAL GO", "FFEB9C", "9C6500"),
        "NO_GO":          ("🚫 NO-GO",           "FFC7CE", "9C0006"),
        "KILL":           ("💀 KILL CRITERIA",   "FF0000", "FFFFFF"),
    }
    label, bg, fg = labels.get(verdict, ("?", "F3F3F3", "000000"))
    c.value = label
    c.fill  = fill(bg)
    c.font  = Font(name="Arial", bold=True, size=11, color=fg)
    c.alignment = Alignment(horizontal="center", vertical="center")
    bdr(c, "thick")
```

---

## 컬럼 너비 및 행 높이

```python
SCORECARD_COL_WIDTHS = {
    "A": 5,   # No.
    "B": 16,  # 평가 축
    "C": 28,  # 항목명(KR)
    "D": 28,  # 항목명(EN)
    "E": 10,  # 점수
    "F": 8,   # 최대점수
    "G": 12,  # 달성률
    "H": 46,  # 근거 메모
}
ROW_HEIGHTS = {
    "title": 34, "subtitle": 20, "header": 28,
    "data": 40, "summary": 32, "verdict": 44,
}
```

---

# PART 2 — Mermaid 플로우차트 템플릿

## 기본 구조

```mermaid
flowchart LR
    START([🔬 약물 후보\n확인]) --> G0{G0\n전임상→IND}

    G0 -->|GO ≥70| G0_GO[✅ IND 신청]
    G0 -->|CGO 50-69| G0_CGO[⚠️ 조건부\n보완 후 재검토]
    G0 -->|NG <50| G0_NG[🚫 개발 중단]
    G0 -->|KILL| G0_K[💀 즉시 종료]

    G0_GO --> G1{G1\nIND→Ph1}
    G1 -->|GO| G1_GO[✅ FIH 개시]
    G1 -->|CGO| G1_CGO[⚠️ 조건부 진행]
    G1 -->|NG/KILL| G1_NG[🚫 종료]

    G1_GO --> G2{G2\nPh1→Ph2}
    G2 -->|GO| G2_GO[✅ Ph2 진입]
    G2 -->|CGO| G2_CGO[⚠️ 확장 Ph1]
    G2 -->|NG/KILL| G2_NG[🚫 종료]

    G2_GO --> G3{G3\nPh2→Ph3\n⭐핵심}
    G3 -->|GO| G3_GO[✅ Ph3 착수]
    G3 -->|CGO| G3_CGO[⚠️ Ph2b 추가]
    G3 -->|NG/KILL| G3_NG[🚫 개발 중단\n또는 파트너링]

    G3_GO --> G4{G4\nPh3→NDA}
    G4 -->|GO| G4_GO[✅ NDA/BLA\n제출]
    G4 -->|CGO| G4_CGO[⚠️ 보완 자료\n수집]
    G4 -->|NG/KILL| G4_NG[🚫 종료]

    G4_GO --> G5{G5\n시판→LCM}
    G5 -->|GO| G5_GO[✅ LCM 착수]
    G5 -->|CGO| G5_CGO[⚠️ 재평가]
    G5 -->|NG| G5_NG[🔚 기존 유지]

    style G3 fill:#FFD700,stroke:#B8860B,stroke-width:3px
    style G0_NG fill:#FFC7CE
    style G1_NG fill:#FFC7CE
    style G2_NG fill:#FFC7CE
    style G3_NG fill:#FFC7CE
    style G4_NG fill:#FFC7CE
    style G0_GO fill:#C6EFCE
    style G1_GO fill:#C6EFCE
    style G2_GO fill:#C6EFCE
    style G3_GO fill:#C6EFCE
    style G4_GO fill:#C6EFCE
    style G5_GO fill:#C6EFCE
```

---

## 단일 게이트 상세 플로우차트 (G3 예시)

```mermaid
flowchart TD
    INPUT([📊 Ph2 데이터\n입력]) --> KILL_CHECK{Kill Criteria\n확인}

    KILL_CHECK -->|K1~K6 발동| KILL[💀 즉시 NO-GO\nKill Criteria 발동]
    KILL_CHECK -->|없음| SCORE[6개 축\n점수 산출]

    SCORE --> SCI_S[SCI: 과학 타당성\n5% 가중]
    SCORE --> CLN_S[CLN: 임상 품질\n35% 가중 ⭐]
    SCORE --> REG_S[REG: 규제 가능성\n15% 가중]
    SCORE --> MKT_S[MKT: 시장/상업성\n20% 가중]
    SCORE --> CMC_S[CMC: 제조 실현성\n5% 가중]
    SCORE --> FIN_S[FIN: 재무 수익성\n20% 가중]

    SCI_S & CLN_S & REG_S & MKT_S & CMC_S & FIN_S --> TOTAL[총점 계산\n0~100점]

    TOTAL -->|≥70점| GO[✅ GO\nPh3 착수]
    TOTAL -->|50~69점| CGO[⚠️ CONDITIONAL GO\n조건 이행 후 재결정]
    TOTAL -->|<50점| NG[🚫 NO-GO\n개발 중단 또는 전략 전환]

    CGO --> CONDITIONS["조건 목록 자동 생성:\n• CLN: 추가 데이터 보완\n• REG: EOP2 미팅 완료\n• FIN: 파트너링 확보"]

    style GO fill:#C6EFCE,stroke:#276221
    style CGO fill:#FFEB9C,stroke:#9C6500
    style NG fill:#FFC7CE,stroke:#9C0006
    style KILL fill:#FF0000,color:#FFFFFF
    style CLN_S fill:#D9EAD3,stroke:#276221,stroke-width:2px
```

---

## Figma:generate_diagram 호출 파라미터

```python
# 전체 파이프라인 플로우차트
figma_params_full = {
    "name": "Go-No-Go 의사결정 트리 — [약물명]",
    "mermaidSyntax": FULL_FLOWCHART_MERMAID,  # 위의 전체 구조
    "userIntent": "바이오파마 약물 개발 단계별 Go/No-Go 의사결정 플로우차트"
}

# 단일 게이트 상세 플로우차트
figma_params_gate = {
    "name": "G3 Ph2→Ph3 Go/No-Go 상세 — [약물명]",
    "mermaidSyntax": GATE_FLOWCHART_MERMAID,
    "userIntent": f"G3 게이트 6개 축 점수 기반 의사결정 상세 플로우차트"
}
```

---

## 조건부 Go 조건 자동 생성 로직

```python
def generate_cgo_conditions(breakdown: dict, threshold=50) -> list:
    """
    breakdown: {"SCI": {"raw": 60, "weight": 0.05, ...}, ...}
    낮은 점수 축을 자동으로 조건 생성
    """
    conditions = []
    condition_templates = {
        "SCI": "전임상/초기 임상 데이터 보완 (N={n}개 항목 미충족)",
        "CLN": "임상 데이터 강화: 추적기간 연장 또는 N 증가",
        "REG": "규제기관 공식 미팅 완료 (EOP2/Pre-NDA) 후 재결정",
        "MKT": "시장성 분석 업데이트 (경쟁사 파이프라인 재조사)",
        "CMC": "GMP 제조 배치 성공 확인 (최소 3로트)",
        "FIN": "파트너링 또는 추가 투자 확보 후 진행",
    }
    for dim_code, data in breakdown.items():
        if data["raw"] < threshold:
            n_failed = int((100 - data["raw"]) / 25)
            cond = condition_templates[dim_code].format(n=n_failed)
            conditions.append(f"[{dim_code}] {cond}")
    return conditions
```
