# 점수 계산 로직 및 판정 규칙 (scoring-rules.md)

## 점수 체계 요약

```
각 항목 점수:    0 / 1 / 2 / 3 / 4점 (5단계)
축 점수:         항목 평균 × 25  →  0~100점
가중 총점:       Σ(축 점수 × 가중치)  →  0~100점
판정:            ≥70=Go  /  50~69=Conditional Go  /  <50=No-Go
```

---

## Python 점수 계산 함수

```python
from dataclasses import dataclass, field
from typing import Dict, List, Optional

@dataclass
class Criterion:
    name_kr: str
    name_en: str
    score: int          # 0~4
    max_score: int = 4
    note: str = ""      # 근거 메모

@dataclass
class DimensionScore:
    code: str           # SCI / CLN / REG / MKT / CMC / FIN
    name_kr: str
    weight: float       # 0.0~1.0
    criteria: List[Criterion] = field(default_factory=list)

    @property
    def raw_score(self) -> float:
        """항목 평균 × 25 → 0~100"""
        if not self.criteria:
            return 0.0
        avg = sum(c.score for c in self.criteria) / len(self.criteria)
        return avg * 25.0

    @property
    def weighted_score(self) -> float:
        return self.raw_score * self.weight


def calculate_gate_score(dimensions: List[DimensionScore]) -> dict:
    total = sum(d.weighted_score for d in dimensions)
    breakdown = {d.code: {
        "raw": round(d.raw_score, 1),
        "weight": d.weight,
        "weighted": round(d.weighted_score, 1),
        "name_kr": d.name_kr
    } for d in dimensions}

    return {
        "total_score": round(total, 1),
        "verdict": verdict(total),
        "breakdown": breakdown
    }


def verdict(score: float) -> str:
    if score >= 70:
        return "GO"
    elif score >= 50:
        return "CONDITIONAL_GO"
    else:
        return "NO_GO"


def check_kill_criteria(flags: Dict[str, bool]) -> Optional[str]:
    """
    flags: {"K1": True/False, "K2": ..., ...}
    하나라도 True면 즉시 NO_GO 반환
    """
    kill_labels = {
        "K1": "치명적/비가역적 독성 (안전역 <3배)",
        "K2": "주요 표적 무효성 (1차 endpoint 완전 실패)",
        "K3": "규제 불가 판정 (CRL 수령)",
        "K4": "CMC 제조 불가",
        "K5": "핵심 특허 상실",
        "K6": "재무 붕괴 (rNPV<0 AND 파트너링 불가)",
    }
    triggered = [kill_labels[k] for k, v in flags.items() if v]
    return triggered if triggered else None
```

---

## 엑셀 입력 인터페이스 설계

### 스코어카드 입력 행 구조
```
[게이트] [축코드] [항목명(KR)] [항목명(EN)] [점수 입력 (0~4)] [최대점수] [근거 메모]
```

### 결과 자동 계산 행 구조
```
[게이트] [축 소계] [가중치] [축 가중점수] [전체 총점] [판정] [Kill Criteria]
```

---

## 점수 입력 드롭다운 값 정의

```
0 = 완전 미충족 / 데이터 없음
1 = 불충분 (심각한 우려)
2 = 부분 충족 (조건부 허용)
3 = 대부분 충족 (경미한 이슈)
4 = 완전 충족 / 기준 초과
```

---

## 판정 색상 코드 (엑셀)

```python
VERDICT_COLORS = {
    "GO":             {"bg": "C6EFCE", "fg": "276221", "label": "✅ GO"},
    "CONDITIONAL_GO": {"bg": "FFEB9C", "fg": "9C6500", "label": "⚠️ CONDITIONAL GO"},
    "NO_GO":          {"bg": "FFC7CE", "fg": "9C0006", "label": "🚫 NO-GO"},
    "KILL":           {"bg": "FF0000", "fg": "FFFFFF", "label": "💀 KILL CRITERIA"},
}
```

---

## 게이트별 가중치 사전 정의 (빠른 참조)

```python
GATE_WEIGHTS = {
    "G0": {"SCI":0.35, "CMC":0.25, "REG":0.20, "FIN":0.10, "MKT":0.10, "CLN":0.00},
    "G1": {"SCI":0.30, "REG":0.25, "CMC":0.20, "CLN":0.10, "FIN":0.10, "MKT":0.05},
    "G2": {"SCI":0.30, "CLN":0.25, "REG":0.15, "MKT":0.15, "FIN":0.10, "CMC":0.05},
    "G3": {"CLN":0.35, "MKT":0.20, "FIN":0.20, "REG":0.15, "SCI":0.05, "CMC":0.05},
    "G4": {"CLN":0.40, "REG":0.30, "CMC":0.15, "FIN":0.10, "MKT":0.05, "SCI":0.00},
    "G5": {"MKT":0.35, "FIN":0.30, "SCI":0.15, "CLN":0.10, "REG":0.05, "CMC":0.05},
}

DIMENSION_NAMES = {
    "SCI": "과학적/기술적 타당성",
    "CLN": "임상 데이터 품질",
    "REG": "규제 가능성",
    "MKT": "시장/상업성",
    "CMC": "CMC/제조 실현성",
    "FIN": "재무/투자 수익성",
}
```

---

## 조건부 Go (CGO) 조건 정의 템플릿

CGO 판정 시 반드시 아래 조건 목록을 자동 생성:

```python
CGO_CONDITIONS_TEMPLATE = {
    "SCI": "전임상 또는 임상 효능 데이터 보완 후 재검토",
    "CLN": "추가 임상 데이터(N 증가 또는 추적기간 연장) 확보 후 재결정",
    "REG": "규제기관 공식 미팅(Pre-IND/EOP2) 완료 후 재검토",
    "MKT": "시장성 분석(경쟁사 파이프라인 업데이트) 완료 후 결정",
    "CMC": "GMP 제조 배치 성공 확인 후 진행",
    "FIN": "파트너링 또는 추가 자금 조달 확인 후 진행",
}
```

---

## rNPV 간이 계산 공식

```python
def calc_rNPV(peak_sales_M: float, royalty_or_margin: float,
              pos: float, discount_rate: float, years_to_launch: int) -> float:
    """
    peak_sales_M:     최고 연매출 추정 (백만 USD)
    royalty_or_margin: 수익률 (0.0~1.0)
    pos:              허가 성공 확률 (0.0~1.0)
    discount_rate:    할인율 (예: 0.10)
    years_to_launch:  허가까지 잔여 연도
    """
    npv = (peak_sales_M * royalty_or_margin * 8) / ((1 + discount_rate) ** years_to_launch)
    return round(npv * pos, 1)

# 예시: peak_sales=500M, margin=20%, PoS=15%, r=10%, 5년 남음
# rNPV = (500*0.2*8) / (1.1^5) * 0.15 = 800/1.61 * 0.15 = 74.5M USD
```

---

## 단계별 산업 평균 성공 확률 (PoS) 참조값

| 단계 | 전체 PoS | 항암 | 희귀질환 | 감염병 |
|------|---------|------|---------|-------|
| 전임상→허가 | 6~10% | 5~7% | 12~18% | 8~12% |
| Ph1→허가 | 10~15% | 8~12% | 16~24% | 12~18% |
| Ph2→허가 | 25~35% | 20~30% | 35~50% | 30~45% |
| Ph3→허가 | 55~70% | 50~65% | 65~80% | 60~75% |

> 출처: BIO/Informa 성공률 분석 (2023), Hay et al.
