# 모달리티별 기준 조정 (modality-adjustments.md)

## 조정 원칙
표준 기준(SM 기준)을 베이스로, 각 모달리티 특성에 따라 가중치·항목·임계값을 조정.  
조정 항목이 없는 축은 표준 기준 그대로 적용.

---

## SM (소분자) — 기준 베이스라인

모든 조정의 기준점. 별도 조정 없음.

**강조 항목**:
- BCS 분류 기반 제형 리스크 (G0 CMC)
- CYP/수송체 DDI 리스크 평가 (G0 CMC)
- hERG 억제·QTc 연장 평가 (G0 SCI)

---

## Protein/항체 (단백질 치료제)

**추가 필수 항목**:
```
SCI 추가: 면역원성(ADA) 발생 위험 평가
CMC 추가: 고차구조(HOS) 안정성, 비교동등성(comparability) 계획
REG 추가: 생물학적 제제 특이 허가 요건 (BLA vs. NDA)
```

**가중치 조정**:
```
CMC 가중치 +5% (G0, G1에서) — 생물의약품 제조 복잡성
CLN 추가 항목: ADA 발생률·임상 영향 평가
```

**Kill Criteria 추가**:
```
K-Bio1: ADA 발생이 PK 완전 소실 유발 + 교차 반응성 확인
K-Bio2: 생물의약품 비교동등성 실패 (후기 CMC 변경 시)
```

---

## ADC (항체약물접합체)

**추가 필수 항목**:
```
SCI 추가: 표적 발현 이질성 및 비종양 조직 발현 평가
CMC 추가: DAR 균일성 (HIC-HPLC), 링커 혈장 안정성(>95%), 유리 페이로드 비율
CLN 추가: on-target off-tumor 독성 프로파일
REG 추가: CDx(동반진단기기) 공동 개발 계획
```

**G0 CMC 특수 기준**:
| 항목 | 0점 | 2점 | 4점 |
|------|-----|-----|-----|
| DAR 균일성 | CV>20% | CV 10~20% | CV<10% |
| 링커 혈장 안정성 | <80% | 80~95% | >95% |
| 유리 페이로드 비율 | >5% | 1~5% | <1% |

**Kill Criteria 추가**:
```
K-ADC1: 유리 페이로드로 인한 전신 독성 > 항체 단독 독성의 2배
K-ADC2: CDx 없이 환자 선정 불가한 표적 발현 다형성
```

---

## CGT (세포/유전자 치료)

**가중치 대폭 조정** (전 게이트 공통):
```
SCI 가중치 +10%  ← pMOA 완전 규명 필수성
CMC 가중치 +5%   ← 제조 복잡성
CLN 가중치 -5%   ← 소규모 임상 허용
FIN 가중치 보통   ← 고가치 단일치료 모델
```

**SCI 추가 필수 항목**:
```
pMOA 완전 규명 (작용기전 체외+체내 검증)
CAR-T: Kill assay, 사이토카인 프로파일, 지속성(persistence) 지표
유전자치료: 삽입 부위 분석(ISA), 발현 지속성
```

**CMC 추가 필수 항목 (G0)**:
| 항목 | 0점 | 2점 | 4점 |
|------|-----|-----|-----|
| 세포 순도 (CD3+ 또는 표적 마커) | <50% | 50~70% | >70% |
| 세포 생존율 출하 기준 | <50% | 50~70% | >70% |
| 벡터 역가 (TU/mL) | 미확립 | 잠정 | GLP 확립 |
| 냉동보존 후 기능 유지 | <50% | 50~70% | >70% |
| 제조 재현성 (성공률) | <70% | 70~90% | >90% |

**CLN 조정**:
```
소규모 임상(N<20) 허용: 점수 감점 없음 (희귀·생명위협 적응증)
대신 반응 지속성(DOR) 기준 강화
15년 장기 추적 계획 수립 여부: G1부터 필수 항목
CRS/ICANS 관리 계획: G1 필수
```

**REG 추가 항목**:
```
15년 장기 추적 프로토콜 승인 여부
삽입 부위 분석(ISA) GLP 완료 여부
벡터 안전성 (복제가능 바이러스 검출)
```

**Kill Criteria 추가**:
```
K-CGT1: 삽입 돌연변이 기인 종양형성 확인
K-CGT2: GvHD Grade 4 이상 (동종 CAR-T)
K-CGT3: 제조 성공률 <70% (3회 연속 실패)
K-CGT4: pMOA 임상 검증 실패 (표적 세포 무반응)
```

---

## Oligo (올리고뉴클레오타이드: siRNA/ASO)

**SCI 추가 항목**:
```
화학 변형 안정성 확인 (2'-OMe/F, PS backbone)
표적 서열 특이성 (off-target 전사체 분석)
조직 내 PK: 혈장 PK가 아닌 간/표적조직 농도 기준
```

**CMC 추가 항목**:
| 항목 | 0점 | 2점 | 4점 |
|------|-----|-----|-----|
| 서열 확인 (ESI-MS) | 없음 | 부분 | 완전 |
| n-1/n+1 불순물 관리 | >5% | 1~5% | <1% |
| GalNAc 접합 효율 | <80% | 80~95% | >95% |

**DDI 평가 불필요 항목**:
```
CYP 기반 DDI: 면제 (낮은 전신 노출)
대신: 신장 수송체(OAT) 경쟁, 혈소판 감소 독성 평가 필수
```

**G1~G2 CLN 특수 기준**:
```
혈장 PK 대신 간 RISC 농도 → PD 상관관계 확립 필수
투여 간격: 분기 1회(GalNAc) 또는 6개월 1회 가능성 평가
```

**Kill Criteria 추가**:
```
K-Oligo1: 간독성(ALT >5× ULN 지속) 해결 불가
K-Oligo2: 혈소판 감소(Grade 3 이상) 지속 + 용량 조정 불가
K-Oligo3: 신장 독성(GFR <60% 감소) 비가역적
```

---

## Vaccine (백신)

**SCI 추가 항목**:
```
면역원성 지속성: 12개월 이상 항체가 유지
세포성 면역(T세포 반응): ELISpot 또는 ICS 확인
Correlate of Protection (CoP) 설정 가능성
```

**CLN 특수 기준**:
```
G2 추가: 어주번트 반응원성(reactogenicity) 프로파일
G3 추가: VE(백신 효과) 하한 95% CI > 30% (WHO 기준)
G4 추가: CoP-based bridging 전략 (소아·노인 면역 브리징)
```

**REG 특수 항목**:
```
WHO 사전 적격성 평가(PQ) 계획 여부
긴급사용승인(EUA) 경로 검토
CoP 기반 accelerated approval 가능성
```

**Kill Criteria 추가**:
```
K-Vac1: 백신 관련 질병 강화(VAERD/ADE) 확인
K-Vac2: 아나필락시스 발생률 >1/10,000 (통상 허용 기준 초과)
K-Vac3: 면역원성 CoP 미달로 VE 예측 불가
```

---

## PROTAC (표적단백질분해제)

**SCI 추가 항목**:
```
Ternary complex 결정 구조 또는 구조-활성 관계 확인
Hook effect 농도 범위 전임상 규명
E3 리가아제 발현 종양 의존성 확인
분해 지속성(protein re-synthesis 속도 대비) 평가
```

**CMC 조정**:
```
MW>700 Da: BCS 기반 제형 리스크 높음 (+항목 가중)
낮은 용해도·투과성: 제형 전략 조기 확립 필수
고체분산체(SDD/HME) 또는 나노제형 필요성 평가
```

**CLN 특수 기준**:
```
G1 추가: Hook effect 임상 용량 범위 탐색 (전통 MTD 불충분)
G2 추가: DC50(분해 농도 50%) 지표 확립
       분해 지속성 vs. 소분자 억제제 비교
G2~G3: 내성 기전(E3 소실, 표적 돌연변이) 모니터링 계획
```

**Kill Criteria 추가**:
```
K-PROTAC1: Hook effect로 인해 임상 가능한 용량 범위 없음
K-PROTAC2: E3 리가아제(CRBN/VHL) 발현 소실 >50% 환자에서 확인
K-PROTAC3: 분해 활성 없이 단순 억제제로만 작용 (PROTAC 우위 없음)
```

---

## 조정 적용 방법

```python
def apply_modality_adjustment(gate: str, modality: str,
                               base_weights: dict) -> dict:
    """
    base_weights: GATE_WEIGHTS[gate] 표준 가중치
    modality: "SM"|"Protein"|"ADC"|"CGT"|"Oligo"|"Vaccine"|"PROTAC"
    """
    adj = base_weights.copy()

    if modality == "CGT":
        adj["SCI"] = min(1.0, adj.get("SCI", 0) + 0.10)
        adj["CMC"] = min(1.0, adj.get("CMC", 0) + 0.05)
        adj["CLN"] = max(0.0, adj.get("CLN", 0) - 0.05)
        # 정규화
        total = sum(adj.values())
        adj = {k: round(v/total, 3) for k, v in adj.items()}

    elif modality == "ADC":
        adj["CMC"] = min(1.0, adj.get("CMC", 0) + 0.05)
        adj["REG"] = min(1.0, adj.get("REG", 0) + 0.05)
        adj["FIN"] = max(0.0, adj.get("FIN", 0) - 0.05)
        adj["MKT"] = max(0.0, adj.get("MKT", 0) - 0.05)
        total = sum(adj.values())
        adj = {k: round(v/total, 3) for k, v in adj.items()}

    return adj
```
