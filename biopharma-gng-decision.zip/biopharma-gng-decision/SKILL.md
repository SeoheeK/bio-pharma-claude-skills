---
name: biopharma-gng-decision
description: >
  바이오파마 약물 개발 단계별 Go/No-Go 의사결정 알고리즘 스킬.
  개발 단계(전임상→IND→Ph1→Ph2→Ph3→NDA/BLA)별 기준 변수를 점수화하고
  Go / Conditional Go / No-Go 판정을 자동 산출하는 스코어카드 엑셀 + Mermaid 플로우차트를 생성함.

  다음 요청에 반드시 사용:
  - "Go/No-Go 의사결정", "개발 단계별 Go-No-Go", "전임상 Go/No-Go 기준"
  - "IND 신청 가능 여부 판단", "Ph2→Ph3 진입 판단", "NDA 제출 가능 여부"
  - "파이프라인 의사결정 프레임워크", "개발 중단 기준", "진입 기준(entry criteria)"
  - "TPP 달성 여부", "Kill criteria", "Development decision gate"
  - "스코어카드 만들어줘", "Go No-Go 점수표", "개발 판단 체크리스트"
  - "efficacy safety CMC regulatory 기준으로 판단", "rNPV 기반 개발 결정"
  - 특정 단계 언급 없이 "이 약물/이 데이터로 계속 개발해야 하나?" 류의 질문

  출력물:
  1. Go/No-Go 스코어카드 엑셀 (.xlsx) — 단계별 탭 + 판정 결과
  2. Mermaid 플로우차트 — 의사결정 트리 시각화
---

# Biopharma Go/No-Go Decision Skill

## 개요

약물 개발 6개 게이트에서의 Go/No-Go 판정을 **6개 기준 축 × 3단계 판정**으로 구조화.  
출력: ① 단계별 스코어카드 엑셀 + ② 의사결정 플로우차트 (Mermaid)

---

## 실행 절차

### Step 1 — 컨텍스트 파악
사용자 입력에서 아래를 추출:
```
- 대상 약물/모달리티 (SM / Protein / ADC / CGT / Oligo / PROTAC 등)
- 현재 개발 단계 (전임상 / IND / Ph1 / Ph2 / Ph3 / NDA)
- 제공된 데이터 있으면 추출 (efficacy 수치, 안전성, CMC 상태 등)
- 없으면 빈 스코어카드 템플릿 생성
```

### Step 2 — 참조 파일 로드
```
references/criteria-by-gate.md   → 게이트별 판정 기준 상세
references/scoring-rules.md      → 점수 계산 로직 + 판정 임계값
references/modality-adjustments.md → 모달리티별 기준 조정
references/excel-template.md     → openpyxl 스타일 코드
```

### Step 3 — 스코어카드 엑셀 생성
```
references/excel-template.md의 공통 함수 사용
단계별 탭(게이트 수만큼) + Overview 탭 + 판정결과 탭
```

### Step 4 — Mermaid 플로우차트 생성
```
Figma:generate_diagram 도구 사용
flowchart LR 방향, 판정 결과(Go/CGo/NG)를 색상으로 구분
references/flowchart-template.md 참조
```

### Step 5 — 출력
```
엑셀 → /mnt/user-data/outputs/ 저장 후 present_files
Mermaid → Figma:generate_diagram으로 FigJam 생성
```

---

## 6개 판정 기준 축 (Dimension)

| 축 | 코드 | 설명 | 가중치 범위 |
|----|------|------|-----------|
| 과학적/기술적 타당성 | SCI | Efficacy POC, 작용기전, 안전성 | 25~35% |
| 임상 데이터 품질 | CLN | 통계적 유의성, endpoint, 바이오마커 | 15~25% |
| 규제 가능성 | REG | 허가 경로, 규제 리스크, 가이던스 정합성 | 15~20% |
| 시장/상업성 | MKT | 시장 규모, 경쟁 환경, 차별화 | 10~20% |
| CMC/제조 실현성 | CMC | 제조 공정, 품질, 스케일업 | 10~15% |
| 재무/투자 수익성 | FIN | NPV, rNPV, 최고 매출 추정 | 10~15% |

> **가중치는 개발 단계와 모달리티에 따라 조정됨**  
> 세부 기준: `references/criteria-by-gate.md` 참조

---

## 3단계 판정 체계

| 판정 | 코드 | 조건 | 의미 |
|------|------|------|------|
| **Go** | GO | 총점 ≥70점 AND Kill Criteria 없음 | 다음 단계 진행 |
| **Conditional Go** | CGO | 총점 50~69점 OR 조건부 이슈 존재 | 조건 이행 후 재검토 |
| **No-Go** | NG | 총점 <50점 OR Kill Criteria 충족 | 개발 중단 또는 전략 전환 |

---

## Kill Criteria (즉시 No-Go 트리거)

어떤 점수와 무관하게 아래 조건 중 하나라도 충족 시 자동 No-Go:
```
K1. 치명적/비가역적 독성 (GLP 독성시험에서 안전역 <3배)
K2. 주요 표적 무효성 (POC 임상에서 1차 endpoint 완전 실패)
K3. 규제 불가 판정 (FDA/EMA complete response letter 수령)
K4. CMC 제조 불가 (GMP 조건 충족 불가 확인)
K5. IP 상실 (핵심 특허 무효화 또는 침해 확정)
K6. 재무 붕괴 (rNPV < 0 AND 파트너링 불가)
```

---

## 개발 게이트 6단계

| 게이트 | 코드 | 전환 결정 | 핵심 질문 |
|--------|------|----------|---------|
| 전임상→IND | G0 | IND 신청 여부 | 안전성·POC 충분한가? |
| IND→Ph1 | G1 | FIH 개시 여부 | 임상 안전 투여 가능한가? |
| Ph1→Ph2 | G2 | Ph2 진입 여부 | 최적 용량·PoC 임상 근거 있는가? |
| Ph2→Ph3 | G3 | Ph3 진입 여부 | 효과 크기·바이오마커 충분한가? |
| Ph3→NDA | G4 | NDA/BLA 제출 여부 | 허가 기준 충족하는가? |
| 시판→LCM | G5 | LCM 전략 결정 | 추가 적응증·제형 개발 가치 있는가? |

> 각 게이트별 세부 점수 기준: `references/criteria-by-gate.md`

---

## 모달리티별 기준 조정 요약

| 모달리티 | 강화 기준 | 완화 기준 |
|---------|---------|---------|
| SM | CMC 스케일업, 제형 BCS | - |
| CGT | pMOA 완전성, 15년 추적, 제조 재현성 | 소규모 임상 허용 |
| ADC | DAR 균일성, 표적 발현 CDx | - |
| Oligo | 조직 내 PK, 화학 변형 안정성 | CYP DDI 불필요 |
| Vaccine | CoP 설정, 면역원성 지속성 | - |
| PROTAC | Hook effect 관리, bRo5 ADMET | 신규 모달리티 완화 |

> 세부 조정 내용: `references/modality-adjustments.md`
