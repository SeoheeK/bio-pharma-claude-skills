# 참조 01: 타겟·질환 유효성 변수 전체 목록

## Module A. 타겟 유효성 (Target Validation)

| 변수 | 정의 | 평가 기준 | 데이터 소스 |
|---|---|---|---|
| 유전적 연관성 | GWAS/MR에서 타겟 유전자와 질환의 인과 연관 | p < 5×10⁻⁸ (GWAS), MR OR 유의 | OpenTargets, GWAS Catalog |
| OpenTargets 증거 등급 | 유전자-질환 통합 증거 점수 | Overall score > 0.5 선호 | OpenTargets Platform |
| LoF/GoF 돌연변이 표현형 | 기능 손실/획득 변이가 질환 표현형 재현 여부 | 인간 LoF → 질환 보호 효과 확인 | ClinVar, OMIM, gnomAD |
| 타겟 발현 적합성 | 질환 조직/세포에서 발현 여부 | 질환 조직 특이적 과발현 또는 기능 이상 | GTEx, Human Protein Atlas |
| 발현 조절 이상 | 환자 vs 정상 발현 차이 | log2FC > 1, FDR < 0.05 | GEO, TCGA, ArrayExpress |
| 동물 모델 표현형 | KO/KI 동물에서 질환 유사 표현형 | 질환 표현형 재현 | MGI, IMPC |
| 타겟 보존성 | 실험 동물 종간 보존 정도 | 마우스-인간 아미노산 동일성 > 85% | UniProt, OrthoMCL |
| 인과 방향성 | 타겟 활성화/억제 중 치료 방향 | MR 방향성 + 인간 LoF 방향 일치 | MR-Base |

## Module B. 질환 생물학 적합성 (Disease Biology Fit)

| 변수 | 정의 | 평가 기준 | 비고 |
|---|---|---|---|
| MoA 적합성 | 억제/활성화/분해 방식이 질환에 적합한가 | 유전 증거 방향과 MoA 일치 | LoF 보호 → 억제제가 맞음 |
| 신호전달 경로 위치 | 질환 핵심 경로 내 타겟 위치 | 상위 조절자(master regulator) 선호 | KEGG, Reactome |
| 경로 중복성 | 타겟 억제 시 보상 경로 존재 여부 | 보상 경로 수 최소화 | STRING 네트워크 |
| PD 바이오마커 가능성 | 타겟 조절 측정 바이오마커 존재 | 정량적 PD 마커 ≥1개 | 임상 바이오마커 DB |
| 질환 서브타입 특이성 | 반응 예측 바이오마커 존재 여부 | predictive biomarker 확인 | 분자 서브타입 분류 연구 |
| 질환 단계 특이성 | 초기/진행/말기 중 타겟 활성 단계 | 개입 시점 명확화 | 자연사 데이터 |
| 내성 기전 위험 | 타겟 조절에 대한 내성 발생 가능성 | 알려진 내성 기전 수 최소화 | 문헌 기반 |

## Module C. 전임상 유효성 증거

| 변수 | 정의 | 평가 기준 | 데이터 소스 |
|---|---|---|---|
| In vitro 효능 예측 | 세포 수준 활성 예측값 | IC50/EC50 < 100 nM | ChEMBL, PubChem Bioassay |
| 세포 표현형 유효성 | 질환 세포 표현형 개선 증거 | 표현형 역전 확인 | 문헌, CMap |
| 동물 PK/PD 상관 | 동물에서 타겟 조절 + 효능 연결 | PD 마커 + 효능 지표 동시 개선 | 전임상 문헌 |
| 치료 지수 예측 (TI) | 효능 농도 vs 독성 농도 비율 | TI > 10 선호 | IC50/CC50 비율 |
| 동물 모델 관련성 | 사용 모델이 인간 질환 재현 정도 | 인간 유전 데이터와 모델 일치도 | 모델 타당성 문헌 |
| 용량-반응 관계 | 농도 증가에 따른 효과 단조 증가 | R² > 0.8의 sigmoid 곡선 | 실험 데이터 |

## Module D. 임상 번역 가능성

| 변수 | 정의 | 평가 기준 | 근거 |
|---|---|---|---|
| 동일 타겟 임상 전례 | 동일 타겟 임상 성공/실패 이력 | 성공 ≥1건 = 타겟 검증됨 | ClinicalTrials.gov |
| 동일 기전 임상 유효성 | 동일 MoA 약물 임상 결과 | Phase 2 성공률 참조 | 문헌 메타분석 |
| 바이오마커 환자 선별 | 반응 예측 바이오마커로 층화 가능 | predictive biomarker 확립 | 동반진단 가능성 |
| 임상 평가변수 실현 가능성 | 규제 수용 primary endpoint 존재 | FDA/EMA 수용 endpoint | 규제 가이던스 |
| 질환 수정 vs 증상 완화 | 근본 원인 치료인가 증상 관리인가 | disease-modifying 선호 | 기전 분석 |
| 환자 집단 크기 추정 | 반응 가능 환자 수 | 임상 실현 가능 규모 | 역학 데이터 |

---

## Module E. 타겟 벨리데이션 모델·데이터셋 지도

타겟 벨리데이션을 5개 층위로 구분하고, 각 층위에 맞는 모델·데이터셋을 매핑한다.
층위마다 필요한 질문이 다르고, 그에 맞는 도구가 다르다.

```
Layer TV-A  인과성 (Causality)         — 이 타겟이 질환의 원인인가
Layer TV-B  드러거빌리티 (Druggability) — 이 타겟에 약이 결합할 수 있는가
Layer TV-C  필수성 (Essentiality)      — 세포/조직에서 이 타겟이 필수적인가
Layer TV-D  안전성 (Safety)            — 이 타겟을 건드리면 부작용이 생기는가
Layer TV-E  발현 적합성 (Expression)   — 올바른 조직·세포에서 발현되는가
```

---

### Layer TV-A. 인과성 모델·데이터셋

**핵심 질문**: 이 단백질 발현/활성 변화가 질환을 일으키는가, 아니면 결과로 나타나는 것인가.

Mendelian Randomization(MR): 유전 변이를 도구 변수로 사용해 타겟 단백질과 질환 간
인과 방향성 추정. 단백질이 분석 대상일 때 수평 다면발현 가정이 강화되어
타겟 MR이 신약 개발 인과 증거의 핵심 도구로 자리잡고 있음.
유전적 증거가 있는 타겟은 임상 성공률이 약 2배 높다는 연구 결과 존재.

#### 분석 모델·도구

| 도구 | 유형 | 핵심 기능 | 접근 |
|---|---|---|---|
| **MR-Base** | 분석 플랫폼 | 수천 개 노출-결과 MR 분석, IEU OpenGWAS 통합 | 공개 웹 + R |
| **TwoSampleMR** | R 패키지 | cis-MR, Steiger filtering, 다중 민감도 분석 | CRAN |
| **Coloc** | 통계 모델 | MR + 공동 국소화(colocalization) 통합, 같은 변이가 두 형질 모두 인과하는지 검정 | R 패키지 |
| **SMR** | 모델 | eQTL → 질환 인과 추정 (Summary-data MR) | 공개 |
| **HEIDI** | 통계 검정 | 이종성(heterogeneity) 검정으로 pleiotropy 배제 | SMR 패키지 내 |
| **G2DR** | AI 프레임워크 | 유전자형 우선 프레임워크로 유전학 기반 타겟 우선순위화 + 약물 재창출 (arXiv 2025) | 논문 공개 |
| **Proteome-by-Phenome MR** | 분석 파이프라인 | pQTL 기반 단백질 전체와 846개 표현형 동시 MR, 38개 인과 단백질 발굴 사례 | 문헌 기반 |

#### 핵심 데이터셋

| 데이터셋 | 내용 | 규모 | URL |
|---|---|---|---|
| **UK Biobank pQTL** | 2,940개 단백질 유전적 매핑, 최대 50,000명 | 2,940 단백질 | UKB 접근 신청 |
| **deCODE Genetics pQTL** | 아이슬란드 코호트 단백질 QTL | 35,000+ 단백질 | 협력 접근 |
| **GWAS Catalog** | 질환-변이 연관 전체 | 수십만 연관 | ebi.ac.uk/gwas |
| **eQTLGen** | 전혈 eQTL, 31,000명+ | 19,250 유전자 | eqtlgen.org |
| **GTEx v10** | 조직별 eQTL (54개 조직) | 공개 | gtexportal.org |
| **FinnGen R12** | 핀란드 바이오뱅크 GWAS | 500,000명+ | finngen.fi |
| **IEU OpenGWAS** | MR용 GWAS 요약 통계 집합 | 35,000+ GWAS | gwas.mrcieu.ac.uk |

#### cis-MR vs trans-MR 선택 기준
```
cis-MR (권장):
  · 타겟 유전자 근처 변이만 도구 변수로 사용
  · 수평 다면발현 위험 낮음
  · 타겟 단백질 자체의 인과성 추정에 적합

trans-MR (보완):
  · 원거리 변이도 포함
  · 경로 수준 인과성 탐색에 유용
  · 다면발현 검증 필수 (HEIDI, Coloc)
```

---

### Layer TV-B. 드러거빌리티 모델·데이터셋

**핵심 질문**: 결합 포켓이 존재하는가, 약물이 붙을 수 있는 구조인가.

AlphaFold3는 단백질 기저 구조뿐 아니라 대안적 형태를 예측해
암호화된(cryptic) 결합 포켓이나 알로스테릭 부위를 드러낸다.
기존에 "undruggable"로 여겨지던 타겟도 재평가 가능.

#### 구조 기반 포켓 탐지 도구

| 도구 | 유형 | 핵심 기능 | 접근 |
|---|---|---|---|
| **fpocket** | 오픈소스 | 결합 포켓 탐지 + 드러거빌리티 로지스틱 모델. 알려진 결합 부위 및 가상 스크리닝 벤치마크에서 최신 성능 | 공개 |
| **DoGSiteScorer** | 웹 서버 | 포켓 크기·극성·드러거빌리티 점수, 서브포켓 분석 | 공개 웹 |
| **SiteMap** (Schrödinger) | 상업용 | 고정밀 결합 포켓 분석, SiteScore + DScore | 유료 |
| **CryptoSite** | ML 모델 | 암호화 결합 포켓 예측 (MD 시뮬레이션 불필요) | 공개 |
| **PocketMiner** | DL 모델 | AlphaFold 구조에서 암호화 포켓 예측 | 공개 |

#### DTA (Drug-Target Affinity) 예측 모델

| 모델 | 유형 | 핵심 특징 | 훈련 데이터 |
|---|---|---|---|
| **PocketDTA** | DL (멀티모달) | AlphaFold 구조 기반 포켓 추출 + DTA 예측 통합. Davis·KIBA에서 SOTA | Davis, KIBA |
| **EMPDTA** | DL | 잔기 수준 포인트클라우드 기반 온라인 포켓 탐지 + DTA 통합. AF2 신뢰도별 성능 평가 포함 | PDBbind, Davis |
| **DynamicDTA** | DL | 동적 디스크립터 + 그래프 표현 결합 (2025) | Davis, KIBA |
| **Protein LM Virtual Screening** | PLM | 구조 없이 단백질 언어 모델만으로 SBDD 수준 가상 스크리닝 (2024) | 대규모 서열 DB |
| **GraphDTA / DGraphDTA** | GNN | 단백질 그래프 + 리간드 그래프 이중 GNN | Davis, KIBA |

#### 드러거빌리티 분류 데이터셋

| 데이터셋 | 내용 | 규모 |
|---|---|---|
| **PDB** | 실험 3D 구조 원천, 2025년 기준 230,000개+ | 230,000+ |
| **PDBbind v2020** | 단백질-리간드 복합체 + 결합 친화도 | 23,000+ 복합체 |
| **BindingDB** | 결합 친화도 실험 데이터 | 2,800,000+ 측정값 |
| **ChEMBL** | 대규모 바이오활성 분자 DB + 약물 유사 특성 | 2,400,000+ 화합물 |
| **AlphaFold DB** | 전체 인간 프로테옴 예측 구조 | 214,000+ 구조 |
| **Davis** | 72개 키나제 × 442개 약물 Kd 측정 | 공개 벤치마크 |
| **KIBA** | 키나제 저해제 바이오활성 Ki/Kd/IC50 통합 | 공개 벤치마크 |
| **DUD-E / LIT-PCBA** | 가상 스크리닝 벤치마크 (디코이 포함) | 공개 |

#### 드러거빌리티 점수 해석 기준
```
fpocket druggability score:
  > 0.5:  드러거블 (결합 포켓 존재)
  0.3~0.5: 경계 (알로스테릭 접근 검토)
  < 0.3:  난드러거블 (펩타이드/PROTAC 전략 전환)

DoGSiteScorer DScore:
  > 0.5:  드러거블
  < 0.5:  추가 검토 필요
```

---

### Layer TV-C. 필수성 모델·데이터셋

**핵심 질문**: 이 타겟을 억제했을 때 암세포는 죽고 정상세포는 살아남는가 (선택적 필수성).

#### 주요 플랫폼

| 플랫폼 | 유형 | 핵심 기능 | 접근 |
|---|---|---|---|
| **DepMap (Cancer Dependency Map)** | 데이터+분석 | CRISPR KO 스크린 900개+ 세포주. Chronos score로 유전자 필수성 정량화. Broad Institute 운영 | depmap.org (공개) |
| **Project Score** (Sanger) | 데이터 | CRISPR 스크린 323개 암세포주. DepMap과 상호 보완 | score.depmap.org |
| **CRISPR-Beret** | ML 모델 | CRISPR 스크린 데이터의 가이드 활성 보정 및 유전자 효과 추정 정밀화 | 공개 |
| **DepMap AI (예측)** | DL | 미측정 세포주의 필수성 점수 예측 | 연구 단계 |
| **BioGRID ORCS** | 데이터 | CRISPR 스크린 큐레이션 데이터베이스 | 공개 |

#### Chronos Score 해석
```
Chronos Score (DepMap):
  < -1.0:  강한 필수성 (암세포 생존에 필수)
  -1.0 ~ -0.5:  선택적 필수 (치료 타겟 후보)
  -0.5 ~ 0:  약한 의존성
  > 0:  비필수 (내성 가능성 높음)

선택성 평가:
  암세포 Chronos < -0.5 + 정상세포 Chronos > -0.2
  → 이상적 종양 선택적 필수 타겟
```

#### 암종별 필수성 히트맵 활용
```
활용 방법:
1. DepMap에서 타겟 유전자 입력
2. 암종별 Chronos score 분포 확인
3. 특정 암종에서만 필수인 타겟 → 적응증 선택 근거
4. 분자 서브타입별 필수성 차이 → 바이오마커 가설 수립
```

---

### Layer TV-D. 안전성 데이터셋

**핵심 질문**: 이 타겟을 조절하면 어떤 부작용이 예측되는가. 정상 조직에서의 역할은 무엇인가.

| 데이터셋·도구 | 내용 | 접근 |
|---|---|---|
| **OpenTargets Safety** | 타겟별 안전성 이벤트, 장기 독성, 임상 이탈 이유, 조직 발현 안전성 통합 | opentargets.org |
| **TDC (Therapeutics Data Commons)** | ADMET + 타겟 안전성 벤치마크 통합 플랫폼, 50+ ML 벤치마크 | tdcommons.ai |
| **DrugBank** | 약물-부작용 데이터 + 타겟 역추적 (승인 약물 타겟 안전성 이력) | drugbank.com |
| **FAERS** | FDA 이상반응 보고 DB → 타겟-부작용 인과 연결 | fda.gov |
| **OffsideDB** | 공식 라벨 외 부작용 DB, 오프타겟 발굴에 활용 | tatonettilab.org |
| **ChEMBL hERG** | hERG 채널 저해 IC50 데이터 대규모 집합 | ebi.ac.uk/chembl |
| **CMap (Connectivity Map)** | 약물 처리 후 전사체 변화 → 타겟 조절 부작용 신호 | clue.io |
| **PharmGKB** | 유전자-약물-표현형 삼각 관계 데이터 | pharmgkb.org |

#### 타겟 안전성 사전 평가 체크리스트
```
□ OpenTargets Safety에서 타겟의 알려진 독성 이벤트 확인
□ 정상 조직에서의 발현 프로파일 (Human Protein Atlas)
□ KO 동물 표현형 (IMPC, MGI) — 치사/불임/장기 이상 여부
□ LoF 변이 보유 인간의 표현형 (gnomAD pLI score)
□ 동일 타겟 약물의 임상 이탈 이유 분석 (ClinicalTrials.gov)
```

#### gnomAD pLI Score (정상 인간에서 LoF 내성)
```
pLI > 0.9:  LoF 불내성 → 이 타겟 억제 시 독성 위험 높음
pLI < 0.1:  LoF 내성 → 억제해도 안전할 가능성
```

---

### Layer TV-E. 발현 적합성 데이터셋

**핵심 질문**: 올바른 질환 조직·세포 유형에서 타겟이 발현되는가.

단일세포 RNA 시퀀싱(scRNA-seq)은 벌크 조직 분석에서 놓칠 수 있는
세포 유형 특이적 타겟을 드러내고, 공간 전사체학은
질환 관련 조직 위치에서 발현되는 타겟을 발견하게 해준다.

| 데이터셋 | 내용 | 규모 | 접근 |
|---|---|---|---|
| **GTEx v10** | 정상 조직 54종 벌크 전사체 + eQTL | 공개 | gtexportal.org |
| **Human Protein Atlas** | 단백질 수준 발현, 조직·세포 이미지, 예후 연관성 | 공개 | proteinatlas.org |
| **TCGA** | 암 조직 전사체·유전체·임상 데이터 | 33개 암종 | portal.gdc.cancer.gov |
| **GEO (Gene Expression Omnibus)** | 질환 vs 정상 DEG 데이터 수천 건 | 5,000,000+ 샘플 | ncbi.nlm.nih.gov/geo |
| **CELLxGENE** | 단일세포 전사체 통합 아틀라스 | 50M+ 세포 | cellxgene.cziscience.com |
| **Human Cell Atlas** | 전체 인체 세포 유형 지도 | 공개 | humancellatlas.org |
| **Allen Brain Atlas** | 뇌 특이적 유전자 발현 (CNS 타겟 필수) | 공개 | brain-map.org |
| **ENCODE** | 조절 요소 + 유전자 발현 통합 | 공개 | encodeproject.org |
| **ArrayExpress** | 기능 유전체학 실험 데이터 | 공개 | ebi.ac.uk/arrayexpress |

#### 발현 적합성 판단 기준
```
이상적 타겟 발현 프로파일:
  ✓ 질환 조직에서 고발현 (log2FC > 1, FDR < 0.05)
  ✓ 질환 관련 세포 유형에서 특이적 발현 (scRNA-seq)
  ✓ 정상 필수 조직 (심장, 간, 신장)에서 저발현
  ✗ 회피: 정상 조직 광범위 고발현 (독성 위험)
  ✗ 회피: CNS 전용 발현 (BBB 투과 필요)
```

---

### 통합 플랫폼 (복수 Layer 동시 지원)

| 플랫폼 | 커버 Layer | 핵심 특징 | 접근 |
|---|---|---|---|
| **OpenTargets Platform** | A+B+D+E | 유전적 증거 + 드러거빌리티 + 안전성 + 임상 전례 통합 점수. ChEMBL 실시간 반영 | opentargets.org |
| **PHAROS / IDG** | B+E | NIH 지원. GPCR·핵수용체·이온채널·키나제 4대 패밀리 집중 분석. TDL 분류 (Tclin/Tchem/Tbio/Tdark) | pharos.nih.gov |
| **DisGeNET** | A+E | 유전자-질환 연관 + 멘델 질환 포함. 1,200,000+ 연관 | disgenet.org |
| **TDC (Therapeutics Data Commons)** | B+C+D | ML 벤치마크 + ADMET + 타겟 친화도 통합. 70+ 벤치마크 태스크 | tdcommons.ai |
| **ChEMBL** | B+D | 바이오활성 + 약물 기전 + 안전성 데이터. API 접근 가능 | ebi.ac.uk/chembl |
| **CandidateDrug4Cancer** | B+C | DepMap + DrugBank 기반 암 타겟 후보 분자 그래프 벤치마크 (2022) | 공개 |

---

### 권장 벨리데이션 실행 순서 (깔때기 구조)

```
Step 1. OpenTargets 통합 점수 조회 (A+B+D+E 동시)
  └─ Overall score < 0.3 → 탈락 (이후 불필요)
  └─ Overall score ≥ 0.3 → Step 2 진행

Step 2. GWAS Catalog + MR-Base (Layer TV-A 정밀화)
  └─ GWAS p < 5×10⁻⁸ 없음 → 유전적 근거 약함 (경고 플래그)
  └─ cis-MR OR 유의 + Coloc PP4 > 0.8 → 인과성 확립

Step 3. AlphaFold3 구조 + fpocket (Layer TV-B)
  └─ DScore < 0.3 → 난드러거블 → PROTAC/펩타이드 전략 전환
  └─ DScore ≥ 0.5 → 드러거블 → DTA 예측 모델 적용

Step 4. DepMap Chronos Score (Layer TV-C)
  └─ Chronos > -0.5 전 암종 → 필수성 없음 → 타겟 재검토
  └─ Chronos < -0.5 특정 암종 → 선택적 필수 → 적응증 확정

Step 5. GTEx + Human Protein Atlas (Layer TV-E)
  └─ 정상 필수 조직 고발현 → 독성 위험 경고
  └─ 질환 조직 특이적 발현 → 발현 적합성 확립

Step 6. OpenTargets Safety + gnomAD pLI (Layer TV-D)
  └─ pLI > 0.9 → 억제 시 독성 위험 높음 (개발 전략 재검토)
  └─ 임상 이탈 이유 분석 → 안전성 MAP 설정

Step 7. 종합 벨리데이션 점수 산출
  └─ A(인과성) + B(드러거빌리티) + C(필수성) + D(안전성) + E(발현)
  └─ → Stage 0 체크리스트 완성 → Stage 1 AI 생성 진입 허가
```

---

### PHAROS TDL (Target Development Level) 분류 활용

PHAROS는 타겟의 지식 성숙도를 4단계로 분류한다.
이 분류는 벨리데이션 전략의 출발점 설정에 유용하다.

| TDL 등급 | 정의 | 전략 |
|---|---|---|
| **Tclin** | 허가 약물 보유 타겟 | 기존 약물 개선·적응증 확장 |
| **Tchem** | 고품질 화학 프로브 존재 | 리드 최적화 단계 가능 |
| **Tbio** | 생물학적 기능 알려짐, 화학 프로브 없음 | 히트 발굴부터 시작 |
| **Tdark** | 거의 알려지지 않은 타겟 | 기초 벨리데이션 전체 필요 |