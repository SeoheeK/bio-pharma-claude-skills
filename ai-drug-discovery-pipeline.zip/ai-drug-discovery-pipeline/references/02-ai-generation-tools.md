# 참조 02: AI 분자 생성 도구 통합 상세

## 도구별 역할 매트릭스

| 도구 | DBTL | 입력 | 출력 | TRL | 핵심 한계 |
|---|---|---|---|---|---|
| Evo2 (Arc Institute) | Design | DNA/단백질 서열 | 기능 예측, 변이체 효과, 새 서열 | 4~5 | 실험 검증 데이터 부족 |
| AlphaFold3 (DeepMind) | Design | 서열 + SMILES | PDB 구조, 결합 포즈, pLDDT | 7~8 | 소분자 포즈 정밀도 한계 |
| REINVENT 4 (AstraZeneca) | Design | SMILES, 보상 함수 | 최적화 SMILES 라이브러리 | 6~7 | 보상 함수 설계 의존성 |
| Bocheming (BayesOpt) | Design+Learn | 특성 공간, 실험 피드백 | 다음 실험 후보 + 불확실성 | 5~6 | 초기 콜드스타트 문제 |

---

## Evo2 활용 상세

### 주요 기능
- **변이체 효과 예측 (Zero-shot)**: 단백질 서열 변이의 기능적 영향 점수화
- **결합 포켓 관련 잔기 중요도**: 어떤 위치가 결합에 중요한지 사전 파악
- **기능성 서열 생성**: 원하는 기능을 가진 새 단백질/펩타이드 서열 생성

### AlphaFold3 연동 방식
```
Evo2 출력 서열 → AlphaFold3 입력 (FASTA)
AlphaFold3 신뢰도 기준: pLDDT ≥ 70 (잔기 수준), ipTM ≥ 0.5 (인터페이스)
```

### 주의사항
- 단백질 패밀리마다 예측 정밀도 편차 큼
- 생성 서열의 실제 발현·정제 성공률 데이터 축적 부족
- 새로운 단백질 패밀리에서 zero-shot 성능 불확실

---

## AlphaFold3 활용 상세

### 주요 기능
- 단백질-소분자 복합체 co-folding
- 결합 포켓 기하학 추출 (binding site geometry)
- pLDDT, pAE, ipTM 기반 신뢰도 평가

### REINVENT 연동 방식
```
AlphaFold3 PDB 출력
  → 결합 포켓 추출 (fpocket, DoGSiteScorer)
  → Pharmacophore 제약 변환
  → REINVENT pharmacophore scoring component 입력
```

### 신뢰도 필터 기준
```
pLDDT ≥ 70: 잔기 수준 구조 신뢰
ipTM ≥ 0.5: 단백질-리간드 인터페이스 신뢰
pAE < 10 Å: 도메인 간 상대 위치 신뢰
```

### 주의사항
- 소분자 결합 포즈 정확도: 전통 도킹(Glide, Vina) 대비 낮은 사례 다수
- Flexible ligand, induced-fit binding에서 오차 증폭
- 구조 신뢰도 ≠ 결합 친화도 (별개 변수)

---

## REINVENT 4 활용 상세

### 주요 기능
- De novo 분자 생성 (RNN/Transformer prior model)
- RL 루프로 다목적 최적화
- Transfer Learning: 유사 타겟 데이터로 prior 모델 조정

### 보상 함수 구성 요소 전체 목록

```python
# 결합 친화도
binding_affinity_score    # 도킹 스코어 (percentile rank 사용 권장)
pharmacophore_score       # AlphaFold3 포켓 기반 pharmacophore 매칭

# 약물 유사성
qed_score                 # Quantitative Estimate of Drug-likeness (0~1)
sa_score                  # Synthetic Accessibility (1~10, 낮을수록 좋음)

# ADMET
admet_absorption_score    # Caco-2, HIA
admet_distribution_score  # BBB, PPB
admet_metabolism_score    # CYP 억제
admet_toxicity_score      # hERG, AMES

# MSAT 제조 가능성
msat_synthesis_score      # SA Score + 빌딩블록 가용성
msat_stability_score      # 화학적 안정성 구조 패턴

# IP
patent_similarity_penalty # SureChEMBL 유사도 (패널티)
novelty_score             # 신규성 (보너스)

# 유효성
selectivity_score         # 오프타겟 대비 선택성
target_engagement_score   # 타겟 결합 특이성
```

### Negative Prior 설정
특허 화합물, PAINS 구조, 오프타겟 결합 구조 → negative prior로 설정해
생성 공간에서 자동 회피하도록 유도

---

## Bocheming (베이즈 최적화) 활용 상세

### 핵심 알고리즘
- **Surrogate Model**: Gaussian Process (GP) 또는 Bayesian Neural Network
- **Acquisition Function**: Expected Improvement (EI), Upper Confidence Bound (UCB)
- **Batch BO**: 병렬 실험을 위한 배치 추천 (q-EI, q-UCB)
- **Multi-Objective BO**: Pareto front 탐색 (EHVI, NSGA-II)

### REINVENT ↔ Bocheming 교차 방식
```
Inner Loop (빠름, 수천 번):
  REINVENT RL 루프 → 분자 생성·평가·보상 업데이트

Outer Loop (느림, 수십 번):
  Bocheming → 실험 조건 추천
           → SDL 실험 실행
           → 실측값 반환
           → GP 업데이트
           → REINVENT 보상 함수 파라미터 조정
```

### 콜드스타트 해결 전략
- 초기 20~50개: Latin Hypercube Sampling으로 무작위 탐색
- 문헌 기반 prior 지식을 GP 평균 함수에 인코딩
- 유사 타겟 데이터로 transfer prior 구성

### 목표 함수 정의 원칙
- 단일 수치로 정의 불가능한 경우 → Multi-Objective BO
- 각 목표의 허용 범위를 제약(constraint)으로 설정
- 핵심 목표(결합 친화도)와 제약 조건(ADMET/MSAT 통과)을 분리