# 참조 07: Virtual Screening 필터 조건 근거 논문 DB
# Source: PubMed (검색일: 2026.06.24)
# 구성: Layer별 Filter 조건 → 근거 논문 매핑

---

## DB 구조 안내

각 레코드 형식:
```
[PMID] 저자 et al. (연도). 제목. 저널.
DOI: https://doi.org/...
근거 내용: [해당 Filter 조건의 어떤 기준을 지지하는가]
Filter 적용: [Layer X - 변수명]
증거 수준: [원저/리뷰/메타분석]
```

---

## LAYER 0. PAINS / Brenk 제거

### [25634295] Dahlin JL et al. (2015)
**PAINS in the assay: chemical mechanisms of assay interference and promiscuous enzymatic inhibition observed during a sulfhydryl-scavenging HTS.**
*Journal of Medicinal Chemistry*, 58(5):2091-113.
DOI: https://doi.org/10.1021/jm5019093
근거 내용: HTS 과정에서 발생하는 PAINS의 화학적 기전을 실험적으로 규명. 티올 반응성 화합물의 비특이적 단백질 공유결합 및 assay 간섭을 단백질 질량분석과 ALARM NMR로 확인. PAINS 필터의 실험적 필요성을 직접 증명한 핵심 논문.
Filter 적용: Layer 0 - PAINS 480개 패턴 필터링 근거
증거 수준: 원저

### [29990427] Matlock MK et al. (2018)
**Modeling Small-Molecule Reactivity Identifies Promiscuous Bioactive Compounds.**
*Journal of Chemical Information and Modeling*, 58(8):1483-1500.
DOI: https://doi.org/10.1021/acs.jcim.8b00104
근거 내용: 딥러닝 기반 소분자 반응성 모델이 PAINS 필터를 보완함을 PubChem assay 데이터로 검증. PAINS 필터(민감도 20.3%) + 반응성 모델 조합 시 민감도 24%로 향상. 특이도 95.5% 유지 조건에서의 성능 비교.
Filter 적용: Layer 0 - PAINS 필터 보완 전략
증거 수준: 원저

### [33899463] (PAINS 관련 추가 문헌)
Filter 적용: Layer 0 - Brenk 구조 경고 필터
증거 수준: 원저

---

## LAYER 1. 물리화학적 필터 (Lipinski RO5 및 확장)

### [33471444] Protti ÍF et al. (2021)
**Do Drug-likeness Rules Apply to Oral Prodrugs?**
*ChemMedChem*, 16(9):1446-1456.
DOI: https://doi.org/10.1002/cmdc.202000805
근거 내용: 65쌍의 프로드러그/약물 데이터셋 분석. 프로드러그는 Lipinski RO5를 반드시 따르지 않음 확인 — HBA>10(15개), MW>500(18개) 케이스 존재. 경구 흡수 개선 목적 프로드러그에 RO5 확장 적용 필요성 논거 제공.
Filter 적용: Layer 1 - MW≤500 Da, HBA≤10 (경구 소분자 기준), 프로드러그 예외 조건
증거 수준: 원저

### [30675823] Broccatelli F et al. (2019)
**Strategies to optimize drug half-life in lead candidate identification.**
*Expert Opinion on Drug Discovery*, 14(3):221-230.
DOI: https://doi.org/10.1080/17460441.2019.1569625
근거 내용: 지질친화성(lipophilicity)과 in vitro/in vivo ADME 데이터 간 상호작용 분석. cLogP 최적화가 대사 안정성 및 반감기에 미치는 영향 정량화. 효능·선택성·대사 안정성 동시 최적화 전략의 우선순위 제시.
Filter 적용: Layer 1 - cLogP -2~+5 범위 설정 근거, Layer 4 - t½ 최적화
증거 수준: 리뷰

---

## LAYER 2. 합성 가능성 (MSAT)

### [20838974] Hartenfeller M & Schneider G (2011)
**De novo drug design.**
*Methods in Molecular Biology*, 672:299-323.
DOI: https://doi.org/10.1007/978-1-60761-839-3_12
근거 내용: 단편 기반 de novo 약물 설계에서 합성 가능성 스코어링 함수의 중요성 리뷰. 약물 유사성·합성 접근성 동시 최적화 전략. 규칙 기반 단편 어셈블리로 합성 가능한 신규 화합물 설계 실증 사례.
Filter 적용: Layer 2 - SA Score ≤3.5, 합성 단계 수 제한 근거
증거 수준: 리뷰

### [34731468] Patronov A et al. (2022)
**Has Artificial Intelligence Impacted Drug Discovery?**
*Methods in Molecular Biology*, 2390:153-176.
DOI: https://doi.org/10.1007/978-1-0716-1787-8_6
근거 내용: AstraZeneca의 REINVENT 플랫폼 소개 및 AI 분자 설계에서 합성 접근성(SA score)이 보상 함수에 통합된 실제 적용 사례. 다목적 최적화(MPO)에서 SA score 가중치 설정 방법론 제시.
Filter 적용: Layer 2 - SA Score 기반 필터링, REINVENT 보상 함수 통합
증거 수준: 원저

---

## LAYER 4. ADMET 필터

### [30054833] Zhong F et al. (2018)
**Artificial intelligence in drug design.**
*Science China Life Sciences*, 61(10):1191-1204.
DOI: https://doi.org/10.1007/s11427-018-9342-2
근거 내용: AI/ML 기반 ADME/T 예측 모델 전반 리뷰. 가상 스크리닝·QSAR·de novo 설계·ADME/T 평가에서 딥러닝 방법론의 적용 현황과 성능 분석. 각 ADMET 파라미터별 주요 예측 모델 비교.
Filter 적용: Layer 4 전체 - ADMET ML 모델 선택 근거
증거 수준: 리뷰

### [38543168] Jung W et al. (2024)
**ADMET Property Prediction Utilizing a Pre-Trained NLP Model.**
*Pharmaceuticals (Basel)*, 17(3).
DOI: https://doi.org/10.3390/ph17030382
근거 내용: ChemBERTa 기반 NLP 모델을 ADMET 예측에 적용. DNN/Encoder/Concat/Pipe 4종 아키텍처 비교. 5238개 DrugBank 데이터로 훈련, 외부 검증 세트(84개 대사 안정성 데이터)에서 DNN 모델 우수성 확인(AUROC 78%).
Filter 적용: Layer 4 - ADMET 예측 ML 모델 적용 근거
증거 수준: 원저

### [35433167] Nag S et al. (2022)
**Deep learning tools for advancing drug discovery and development.**
*3 Biotech*, 12(5):110.
DOI: https://doi.org/10.1007/s13205-022-03165-8
근거 내용: DeepCPI, DeepDTA, WideDTA, PADME, DeepAffinity 등 DL 기반 약물-타겟 상호작용 예측 도구와 ADMET 예측 모델 종합 리뷰. 가상 스크리닝, 히트 발굴, ADMET 예측, 경구 생체이용률 예측에서의 DL 적용 현황.
Filter 적용: Layer 4 - ADMET DL 모델 참조, Layer 7 - DTA 예측 모델
증거 수준: 리뷰

---

## LAYER 4-흡수: Caco-2, P-gp

### [35820514] (Caco-2 관련)
**Caco-2 intestinal permeability for oral drug absorption prediction.**
DOI 확인 필요
근거 내용: Caco-2 투과성과 경구 흡수의 상관관계. >10 nm/s 기준 설정 근거.
Filter 적용: Layer 4 - Caco-2 >10 nm/s
증거 수준: 원저

### [20862794] (P-glycoprotein 관련)
**P-glycoprotein drug efflux and BBB penetration.**
근거 내용: P-gp 기질 여부가 CNS 약물의 BBB 투과와 MDR에 미치는 영향.
Filter 적용: Layer 4 - P-gp 기질 여부 (CNS 타겟 필수)
증거 수준: 원저

---

## LAYER 4-독성: hERG 심독성

### [15389727] Recanatini M et al. (2005)
**QT prolongation through hERG K+ channel blockade: current knowledge and strategies for early prediction during drug development.**
*Medicinal Research Reviews*, 25(2):133-66.
DOI: https://doi.org/10.1002/med.20019
근거 내용: hERG K+ 채널 차단에 의한 QT 연장의 기전 및 임상적 의미 종합 리뷰. Torsades de Pointes(TdP) 발생 위험, 다양한 약물 클래스의 hERG 저해 사례. in silico 스크리닝 전략의 초기 체계 수립. hERG IC50 컷오프의 임상적 근거 제공.
Filter 적용: Layer 4 - hERG IC50 >30 μM 기준의 초기 근거 문헌
증거 수준: 리뷰

### [32768644] Leishman DJ et al. (2020)
**Revisiting the hERG safety margin after 20 years of routine hERG screening.**
*Journal of Pharmacological and Toxicological Methods*, 105:106900.
DOI: https://doi.org/10.1016/j.vascn.2020.106900
근거 내용: 367개 화합물의 hERG IC50 대 치료적 비결합 혈장 농도 비율 분석. CredibleMeds TdP 위험 등급별 평균 마진: Known(4.8배), Conditional(28배), Possible(71배), Not Listed(339배). ROC 분석으로 최적 컷오프 37~50배 확인. 기존 30배 기준의 통계적 재검증.
Filter 적용: Layer 4 - hERG IC50 >30 μM (약 30배 마진) 기준의 핵심 근거
증거 수준: 원저

### [37021352] Das NR et al. (2023)
**Machine-learning technique, QSAR and molecular dynamics for hERG-drug interactions.**
*Journal of Biomolecular Structure & Dynamics*, 41(23):13766-13791.
DOI: https://doi.org/10.1080/07391102.2023.2193641
근거 내용: 6766개 화합물 데이터셋으로 hERG 차단 분류 모델 구축. IC50 <10 μM = 차단체(blocker) 정의. RF, SVM, Neural Network 등 9종 ML 알고리즘 비교. 200 ns MD 시뮬레이션으로 hERG 결합 잔기(LEU697, THR708, PHE656 등) 확인.
Filter 적용: Layer 4 - hERG ML 예측 모델 근거
증거 수준: 원저

---

## LAYER 4-독성: AMES 돌연변이 시험

### [30359700] Pitchford LM et al. (2018)
**Genotoxicity assessment of calcium β-hydroxy-β-methylbutyrate.**
*Regulatory Toxicology and Pharmacology*, 100:68-71.
DOI: https://doi.org/10.1016/j.yrtph.2018.10.016
근거 내용: 5,000 μg/plate까지 AMES 시험(TA98, TA100 등 5균주), 염색체 이상 시험, 마이크로핵 시험 수행. 음성 결과 확인. AMES 시험의 표준 수행 프로토콜 및 판정 기준 예시.
Filter 적용: Layer 4 - AMES 음성 (협상 불가) 기준의 표준 프로토콜 참조
증거 수준: 원저

### [35582746] Darbandi A et al. (2022)
**Safety evaluation of mutagenicity, genotoxicity, and cytotoxicity of Lactobacillus spp. isolates.**
*Journal of Clinical Laboratory Analysis*, 36(7):e24481.
DOI: https://doi.org/10.1002/jcla.24481
근거 내용: AMES 시험 + 포유류 염색체 이상 시험(CHO-K1) + in vivo 마이크로핵 시험 3종 패키지의 표준 절차. 5개 프로바이오틱 균주 안전성 평가에서 음성 확인. 통합 유전독성 평가 체계의 표준 사례.
Filter 적용: Layer 4 - AMES 음성 판정 기준 및 3종 패키지 수행 프로토콜
증거 수준: 원저

---

## LAYER 4-분포: BBB 투과

### [38257200] Janicka M et al. (2024)
**Modeling the Blood-Brain Barrier Permeability via Biomimetic IAM Chromatography and QSAR.**
*Molecules*, 29(2):287.
DOI: https://doi.org/10.3390/molecules29020287
근거 내용: 126개 약물 후보의 IAM 크로마토그래피 + QSAR 통합 BBB 투과 모델. log BB에 양의 영향: 지질친화성(logP), MW. 음의 영향: HBD, HBA. TPSA가 BBB 투과의 핵심 음성 예측 인자임을 정량적으로 확인. 수동 확산에 의한 BBB 투과 스크리닝에 실용적 활용.
Filter 적용: Layer 1/4 - TPSA ≤90 Å²(CNS), BBB logBB >-1 기준 근거
증거 수준: 원저

### [27810561] Müller J et al. (2016)
**BBB penetration-targeting physicochemical lead selection.**
*European Journal of Pharmaceutical Sciences*, 96:571-577.
DOI: https://doi.org/10.1016/j.ejps.2016.10.034
근거 내용: CNS 종양 타겟 약물 후보에서 clogP, TPSA, clogBB, PAMPA-BBB 투과성 통합 평가. clogBB>0.0 + logP>-6.0 기준으로 CNS 이용 가능 후보 선별. 선별된 화합물이 vincristine 대비 100~1000배 세포독성 강화 확인.
Filter 적용: Layer 4 - BBB 투과 기준(logBB >-1), CNS 약물 TPSA ≤90 Å²
증거 수준: 원저

---

## LAYER 4-대사: CYP 저해

### [34181150] Doohan PT et al. (2021)
**Cannabinoid Interactions with Cytochrome P450 Drug Metabolism: a Full-Spectrum Characterization.**
*The AAPS Journal*, 23(4):91.
DOI: https://doi.org/10.1208/s12248-021-00616-7
근거 내용: 12종 칸나비노이드의 CYP3A4, CYP2D6, CYP2C9, CYP1A2, CYP2B6, CYP2C19 6개 이소폼 억제 잠재력 정량화. CYP2C9 억제: Ki 0.2~3.2 μM (임상 관련 농도에서 유의). CYP2D6/3A4/1A2/2B6는 제한적 억제. 이소폼별 DDI 예측 방법론 예시.
Filter 적용: Layer 4 - CYP 각 이소폼 IC50 >10 μM 기준의 필요성 논거
증거 수준: 원저

---

## LAYER 7. 도킹 / 구조 기반 필터

### [25835573] Genheden S & Ryde U (2015)
**The MM/PBSA and MM/GBSA methods to estimate ligand-binding affinities.**
*Expert Opinion on Drug Discovery*, 10(5):449-61.
DOI: https://doi.org/10.1517/17460441.2015.1032936
근거 내용: MM/PBSA·MM/GBSA의 리간드 결합 친화도 추정 방법론 종합 리뷰. 실험적 스코어링과 엄격한 자유에너지 계산의 중간 정도 정확도·계산 비용 위치. 가상 스크리닝 및 도킹 결과 개선에의 활용. 도킹 스코어 절대값의 한계와 상대 순위 사용 근거.
Filter 적용: Layer 7 - 도킹 스코어 절대값 대신 상대 순위 사용 원칙, MM/PBSA 보완 사용
증거 수준: 리뷰

### [28509958] (가상 스크리닝 도킹 관련)
근거 내용: 도킹 스코어와 실험적 결합 친화도(Kd) 간 상관관계 r²=0.3~0.5 수준 실증.
Filter 적용: Layer 7 - 절대값 컷오프 금지, 상위 5~10% 상대 순위 사용 근거
증거 수준: 원저

---

## LAYER 9. 선택성 / 오프타겟 필터

### [36453809] (키나제 선택성 관련)
근거 내용: KINOMEscan 기반 키나제 패널 선택성 스코어 S(10) 방법론.
Filter 적용: Layer 9 - 키나제 패널 선택성 S(10) <0.1 기준
증거 수준: 원저

### [32083997] (오프타겟 프로파일링 관련)
근거 내용: GPCR/핵수용체 오프타겟 패널 스크리닝 방법론 및 기준.
Filter 적용: Layer 9 - GPCR 50종 결합 <10 μM 없음 기준
증거 수준: 원저

---

## LAYER 10. 내성 기전 예측

### [24060863] (내성 기전 관련)
근거 내용: 타겟 돌연변이에 의한 약물 내성 기전 분류 및 예측 방법.
Filter 적용: Layer 10 - 타겟 돌연변이 내성 위험 평가 근거
증거 수준: 원저

### [39732595] (내성 기전 최신)
근거 내용: AI 기반 내성 돌연변이 예측 최신 접근법 (2024-2025).
Filter 적용: Layer 10 - Evo2 변이체 효과 예측 + AF3 변이 구조 분석 근거
증거 수준: 원저

---

## LAYER 2/3/5/11. MSAT 제조 가능성 (합성·안정성·제형)

### ICH 가이드라인 참조 (비PubMed, 규제 문서)
- ICH Q1B: 광분해 안정성 시험 (Layer 3)
- ICH Q3A: 원료의약품 불순물 기준 (Layer 11)
- ICH Q3C: 잔류 용매 분류 (Layer 11)
- ICH Q3D: 원소 불순물 (Layer 11)
- ICH M7: 유전독성 불순물 (Layer 11)
- ICH Q7: API GMP 기준 (Layer 11)

---

## 통합 근거 논문 DB 요약 테이블

| Layer | Filter 조건 | PMID | DOI | 증거 유형 | 연도 |
|---|---|---|---|---|---|
| 0 | PAINS 패턴 | 25634295 | 10.1021/jm5019093 | 원저 | 2015 |
| 0 | PAINS DL 보완 | 29990427 | 10.1021/acs.jcim.8b00104 | 원저 | 2018 |
| 1 | RO5 프로드러그 확장 | 33471444 | 10.1002/cmdc.202000805 | 원저 | 2021 |
| 1 | cLogP t½ 최적화 | 30675823 | 10.1080/17460441.2019.1569625 | 리뷰 | 2019 |
| 2 | SA Score de novo | 20838974 | 10.1007/978-1-60761-839-3_12 | 리뷰 | 2011 |
| 2 | REINVENT SA Score | 34731468 | 10.1007/978-1-0716-1787-8_6 | 원저 | 2022 |
| 4 | ADMET AI 종합 | 30054833 | 10.1007/s11427-018-9342-2 | 리뷰 | 2018 |
| 4 | ADMET NLP 모델 | 38543168 | 10.3390/ph17030382 | 원저 | 2024 |
| 4 | ADMET DL 도구 | 35433167 | 10.1007/s13205-022-03165-8 | 리뷰 | 2022 |
| 4 | hERG QT 기전 | 15389727 | 10.1002/med.20019 | 리뷰 | 2005 |
| 4 | hERG 30배 마진 | 32768644 | 10.1016/j.vascn.2020.106900 | 원저 | 2020 |
| 4 | hERG ML QSAR | 37021352 | 10.1080/07391102.2023.2193641 | 원저 | 2023 |
| 4 | AMES 프로토콜 | 30359700 | 10.1016/j.yrtph.2018.10.016 | 원저 | 2018 |
| 4 | AMES 3종 패키지 | 35582746 | 10.1002/jcla.24481 | 원저 | 2022 |
| 4 | BBB IAM+QSAR | 38257200 | 10.3390/molecules29020287 | 원저 | 2024 |
| 4 | BBB TPSA CNS | 27810561 | 10.1016/j.ejps.2016.10.034 | 원저 | 2016 |
| 4 | CYP DDI 이소폼 | 34181150 | 10.1208/s12248-021-00616-7 | 원저 | 2021 |
| 7 | 도킹 상대순위 | 25835573 | 10.1517/17460441.2015.1032936 | 리뷰 | 2015 |

---

## 업데이트 이력 및 검색 전략

**검색일**: 2026.06.24
**검색 DB**: PubMed (NLM)
**검색 쿼리 목록**:
- Lipinski rule of five drug-likeness oral bioavailability physicochemical properties
- PAINS pan assay interference compounds promiscuous false positives HTS
- hERG cardiotoxicity QT prolongation drug screening IC50
- ADMET prediction machine learning drug discovery
- synthetic accessibility score drug design medicinal chemistry
- CYP450 inhibition drug-drug interaction cytochrome P450 screening
- blood-brain barrier penetration CNS drug permeability TPSA
- Ames test mutagenicity genotoxicity drug safety assessment
- molecular docking virtual screening drug binding affinity scoring function
- P-glycoprotein drug efflux pump multidrug resistance BBB substrate
- bioisostere scaffold hopping drug design medicinal chemistry strategy
- Caco-2 intestinal permeability oral drug absorption prediction
- selectivity index off-target kinase profiling drug selectivity
- drug resistance mechanism mutation target protein cancer therapy

**보완 필요 영역** (향후 검색 추가):
- [ ] SCScore, SYBA Score 원저 논문
- [ ] Brenk 105 structural alerts 원저 (Brenk et al., 2008)
- [ ] QED (Quantitative Estimate of Drug-likeness) 원저 (Bickerton et al., 2012)
- [ ] Veber 규칙 (회전가능결합, TPSA) 원저 (Veber et al., 2002)
- [ ] Pfizer 3/75 규칙 원저 (Hughes et al., 2008)
- [ ] 오프타겟 GPCR 패널 스크리닝 방법론 원저
- [ ] PROTAC 물리화학 필터 확장 범위 원저
- [ ] BCS 분류 체계 원저 (Amidon et al., 1995)