# 참조 04: DBTL 루프 설계 (Benchiling + SDL + Bocheming)

## 세 요소 역할 정의

| 요소 | DBTL 위치 | 핵심 기능 | 주요 인터페이스 |
|---|---|---|---|
| Benchiling | T + L 허브 | ELN, 프로토콜 버전 관리, 기기 API 연동 | REST API, 기기 직결 |
| SDL | B + T 실행 엔진 | 자율 합성·측정·스크리닝 | 로봇 제어 API |
| Bocheming | D + L 최적화 뇌 | GP Surrogate, Acquisition Function | Python API |

---

## DBTL 루프 상세 설계

### [D] Design — Bocheming
```
입력: 이전 실험 (X_observed, Y_observed)
처리:
  1. GP Posterior 갱신
  2. Acquisition Function 계산 (EI/UCB/qEI)
  3. Batch 실험 조건 n개 선택 (병렬 실험 묶음)
  4. 탐색(Exploration) vs 활용(Exploitation) 균형 자동 조정
출력: 실험 파라미터 세트 n개
      (서열, 농도, pH, 온도, 배양 시간, 유도 조건 조합)
```

### [B] Build — SDL
```
입력: Benchiling 프로토콜 (Bocheming 추천 조건 → 자동 변환)
처리:
  - 시약 재고 자동 확인·발주
  - 액체 처리 로봇 (Hamilton / Opentrons / Tecan)
  - DNA 어셈블리 (Golden Gate, Gibson)
  - 형질전환·배양 자동화
  - 소분자: 마이크로리액터 합성
로깅: 각 단계 자동 Benchiling 기록 (타임스탬프, 배치 ID, 편차)
```

### [T] Test — SDL + Benchiling
```
자동 측정 모듈:
  - HTS: 형광 리포터, 생존율, 효소 활성, FACS, 플레이트 리더
  - 분석: LC-MS (대사산물), SPR/ITC (결합 친화도), qPCR, NGS
Benchiling 연동:
  - 측정값 자동 업로드 (기기 API 직결)
  - 이상치(outlier) 자동 플래그
  - 실험 메타데이터 자동 태깅
  - 샘플 계보(lineage) 자동 기록
```

### [L] Learn — Bocheming + Benchiling
```
입력: Benchiling 구조화 데이터 → 표준 스키마 자동 변환
처리:
  - 배치 QC 통과 여부 필터링
  - GP Posterior 갱신
  - 상위 AI 모델 피드백 (선택):
    · 충분한 데이터 축적 시 REINVENT 재훈련
    · Evo2 예측 vs 실측치 격차 추적
  - 필터 범위 업데이트 메타 루프 트리거
출력: 다음 D 사이클 자동 트리거
```

---

## 전통 DBTL vs SDL 통합 DBTL 비교

| 차원 | 전통 DBTL | SDL 통합 DBTL |
|---|---|---|
| 사이클 시간 | 2~4주/회전 | 24~72시간/회전 |
| 병렬 실험 수 | 10~50개 (인력 제한) | 수백~수천 개 |
| 재현성 | CV 10~30% (실험자 의존) | CV 1~5% (로봇 정밀도) |
| 데이터 품질 | 수동 입력 오류 내재 | 기기 직결, 완전 메타데이터 |
| Bocheming 학습 속도 | 데이터 희소, 수렴 느림 | 데이터 풍부, 빠른 수렴 |
| Negative Data 활용 | 비기록 | 구조화 데이터로 학습 |
| 연구자 역할 | 모든 단계 직접 수행 | 목표 설정·이상 감지·해석 |

---

## Benchiling의 핵심 역할 상세

### 1. 프로토콜 버전 관리 → Build 재현성 보장
- 실험 조건 변경 자동 버전 트래킹
- 어떤 프로토콜 버전에서 어떤 결과 → 완전 추적
- Bocheming 디버깅 시 프로토콜 편차 로그가 결정적 정보

### 2. 기기 API 통합 → 수동 입력 제거
- Hamilton, Opentrons, 바이오리액터, 플레이트 리더 직접 연동
- SDL 데이터 → Benchiling DB 자동 구조화 축적
- 없으면 DBTL 루프 속도 = 인간 데이터 입력 속도로 제한

### 3. 샘플 계보 추적
```
DNA 파트 → 균주 → 배양 조건 → 측정값
  (인과 체인 자동 기록)
  → Bocheming의 (input X, output Y) 쌍 신뢰성 확보
```

### 4. 규제 데이터 적격성 (GxP 연동)
- FDA 21 CFR Part 11 전자 기록 무결성
- SDL 자동 생성 데이터의 GxP 적격성 = 시스템별 별도 검증 필요
- 자율 루프 데이터의 규제 허용 여부: 현재 명확한 가이던스 없음 (규제 공백)

---

## 핵심 설계 결정사항 (구현 시 반드시 결정)

### 결정 1. Inner/Outer 루프 교차 방식
```
옵션 A: 완전 분리
  - REINVENT RL (Inner): 수천 번, 계산 기반
  - Bocheming BO (Outer): 수십 번, 실험 기반
  - 연결: Outer 결과 → Inner 보상 함수 파라미터 업데이트

옵션 B: 통합 루프
  - Bocheming이 REINVENT 탐색 공간 자체를 안내
  - 더 효율적이나 구현 복잡도 높음
```

### 결정 2. 인터페이스 미들웨어
- 현재 Benchiling ↔ Bocheming 표준 API 없음 → 커스텀 개발 필요
- 권장: REST API 기반 이벤트 드리븐 아키텍처
- 데이터 스키마: FAIR 원칙 준수 (Findable, Accessible, Interoperable, Reusable)

### 결정 3. 노이즈 모델링
- SDL 고속 처리 → 측정 정밀도 희생 가능
- GP 노이즈 파라미터 별도 추정 필수
- 이상치 필터링: Benchiling 단계에서 자동 플래그 + 수동 검토

### 결정 4. 필터 범위 메타 업데이트 주기
- 권장: 5~10 DBTL 사이클마다 또는 데이터 100개 누적 시
- 업데이트 대상: Layer 1 물리화학, Layer 4 ADMET 절대값 기준
- 보상 함수 가중치(w1~w7)도 동시 재조정

---

## 글로벌 구현 현황 참조

| 기관 | 수준 | 특징 |
|---|---|---|
| MIT Self-Driving Labs | 연구 | Olympus 프레임워크, BO+로봇 통합 |
| CMU Accelerate | 파일럿 | 배터리 소재, 완전 자율화 |
| Emerald Cloud Lab | 상업화 | 클라우드 기반 SDL 서비스 |
| Strateos | 상업화 | SDL-as-a-Service |
| KRIBB 바이오파운드리 | 구축 중 | 장비 자동화 단계, DBTL 루프 미완성 |
| KAIST 공학생물학 | 연구 | 합성생물학 DBTL 연구 |