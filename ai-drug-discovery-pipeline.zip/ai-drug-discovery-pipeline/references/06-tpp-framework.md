# 참조 06: TPP (Target Product Profile) 수립 프레임워크

## TPP의 정의와 Filter와의 관계

TPP는 Virtual Screening 필터 조건들의 **역방향 번역**이다.

```
Filter 방향 (탈락 조건):
  "이 분자가 이 기준을 충족하지 못하면 제거한다"
  → 분자 중심, 계산·실험 언어

TPP 방향 (도달 목표):
  "최종 제품이 이 기준을 반드시 갖춰야 한다"
  → 제품 중심, 임상·규제·시장 언어
```

### Filter → TPP 변환 원칙

| Filter 층위 | TPP 섹션 | 변환 방식 |
|---|---|---|
| 물리화학·MSAT | 제형·투여 경로 목표 | 필터 통과 기준 → 최소 요구 사양 |
| ADMET | 안전성·PK 프로파일 | 예측 컷오프 → 임상 허용 범위 |
| 유효성·타겟 | 임상 효능 목표 | 전임상 기준 → 임상 성공 기준 |
| 선택성·오프타겟 | 안전성 프로파일 | 오프타겟 패널 → 부작용 허용 범위 |
| IP | 상업화 요건 | FTO + 특허 가능 → 독점 기간 목표 |
| 시장성·임상 | 상업화 목표 | rNPV 입력값 → 시장 포지셔닝 |

---

## TPP 표준 구조 (ICH E8 / FDA 가이던스 기반)

TPP는 **Minimum Acceptable Profile (MAP)** 과 **Optimal Profile (OP)** 두 열로 구성한다.
- MAP: 이것 이하면 개발 중단 (No-Go 기준과 직결)
- OP: 이것을 달성하면 시장 차별화 가능 (전략적 목표)

---

## Section 1. 적응증 및 타겟 환자군

| 항목 | Minimum Acceptable | Optimal |
|---|---|---|
| 적응증 | 단일 적응증, 2차 치료 이상 | 1차 치료 또는 복수 적응증 |
| 타겟 환자군 | 바이오마커 선택 서브그룹 | 바이오마커 미선별 전체 환자군 |
| 환자 수 (미국) | >50,000명/년 | >200,000명/년 |
| 질환 단계 | 진행성/말기 | 초기~말기 전 단계 |
| 연령 | 성인 (18세+) | 소아 포함 |

**Filter 연결**: 타겟 유효성 Module A (유전적 연관성, 발현 적합성) → 환자군 정의
**Bocheming 피드백**: 환자 서브타입별 반응률 데이터 → MAP/OP 경계 업데이트

---

## Section 2. 임상 효능 목표 (Efficacy Endpoints)

| 항목 | Minimum Acceptable | Optimal |
|---|---|---|
| 1차 평가변수 | 규제 수용 대리 평가변수 (PFS, ORR 등) | OS 또는 QoL 개선 |
| SoC 대비 효능 개선 | HR < 0.80 또는 ORR 절대 증가 ≥15% | HR < 0.65 또는 CR율 2배 이상 |
| 반응 지속 기간 | DoR ≥ 6개월 | DoR ≥ 12개월 |
| 바이오마커 반응률 | 반응자 서브그룹 ORR ≥ 30% | 전체 환자군 ORR ≥ 50% |
| 내성 발생 시점 | 중앙값 PFS ≥ 6개월 | 중앙값 PFS ≥ 12개월 |

**Filter 연결**:
- Layer 8 (질환 유효성) → IC50, TI → 임상 효능 목표로 환산
- Layer 10 (내성 기전) → 내성 발생 시점 MAP 설정
- 전임상 TI > 10 → 임상 치료 지수 목표로 스케일링

---

## Section 3. 안전성 프로파일 (Safety Profile)

| 항목 | Minimum Acceptable | Optimal |
|---|---|---|
| 심독성 (hERG) | QTc 연장 < 20ms (임상) | QTc 연장 < 10ms |
| 간독성 | AST/ALT < 3×ULN (Grade ≤ 2) | 정상 범위 유지 |
| 혈액독성 | Grade ≤ 2 (Grade 3 일시적 허용) | Grade ≤ 1 |
| 면역독성 | irAE Grade ≤ 2 (관리 가능) | irAE Grade ≤ 1 |
| 신독성 | 혈청 크레아티닌 < 1.5×baseline | 정상 범위 |
| Grade ≥ 3 AE 비율 | < 30% | < 15% |
| DLT 비율 (Phase 1) | < 33% (DLT 정의 용량에서) | < 20% |
| 치료 중단율 | < 20% | < 10% |

**Filter 연결**:
- Layer 4 ADMET (hERG IC50 > 30μM) → QTc 목표
- Layer 4 ADMET (AMES 음성) → 유전독성 안전성
- Layer 9 선택성 (오프타겟 ≥100배) → Grade ≥ 3 AE 비율 목표
- Layer 10 내성 기전 → 내성 시 재발 안전성 프로파일

---

## Section 4. PK/PD 프로파일

| 항목 | Minimum Acceptable | Optimal |
|---|---|---|
| 투여 경로 | 경구 (1일 1~2회) 또는 IV (주 1회) | 경구 1일 1회 |
| 생체이용률 (F) | > 20% (경구) | > 50% |
| t½ | 8~24시간 (QD 투여 지지) | 12~24시간 |
| 타겟 점유율 (Ctrough) | ≥ 80% 점유 유지 | ≥ 90% 점유 유지 |
| 식이 영향 | 고지방식 대비 AUC 변화 < 50% | < 20% |
| DDI 위험 | 주요 CYP 억제 없음 (IC50 > 10μM) | 모든 CYP 안전 + 트랜스포터 안전 |
| BBB 투과 (CNS 타겟) | logBB > 0 또는 Kp,uu,brain > 0.1 | Kp,uu,brain > 0.3 |
| Vss | 조직 분포 충분 (Vss > 0.5 L/kg) | 표적 조직 농축 확인 |

**Filter 연결**:
- Layer 1 (MW, cLogP, TPSA) → 경구 생체이용률 목표
- Layer 4 ADMET (Caco-2, HIA, t½, CYP) → PK 프로파일 직접 변환
- Layer 4 분포 (BBB) → CNS 타겟 시 BBB 투과 목표

---

## Section 5. CMC / 제조 요건 (MSAT 연동)

| 항목 | Minimum Acceptable | Optimal |
|---|---|---|
| 합성 단계 수 | ≤ 12단계 | ≤ 8단계 |
| 총 합성 수율 | > 5% | > 15% |
| 배치 일관성 | 순도 ≥ 98% (API) | 순도 ≥ 99.5% |
| 불순물 제어 | ICH Q3A 기준 충족 | 주요 불순물 < 0.05% |
| 보관 안정성 | 25°C/60%RH 24개월 | 40°C/75%RH 6개월 이상 |
| 스케일업 가능성 | kg 단위 합성 확인 | 100kg 이상 GMP 생산 |
| 원료 공급원 | ≥ 1개 공급원 (QP) | ≥ 2개 이상 공급원 다각화 |
| 제형 형태 | 캡슐/정제 (경구) 또는 바이알 (IV) | 환자 편의 맞춤 제형 |
| 특수 제조 조건 | 상온·대기압 합성 가능 | Class I 용매만 사용 |

**Filter 연결**:
- Layer 2 (SA Score, 단계 수, 수율) → 합성 단계·수율 MAP
- Layer 3 (화학적 안정성) → 보관 안정성 MAP
- Layer 11 (스케일업, 불순물) → CMC 전체 요건

---

## Section 6. IP / 상업화 요건

| 항목 | Minimum Acceptable | Optimal |
|---|---|---|
| 특허 보호 기간 | 허가 후 잔여 특허 ≥ 8년 | ≥ 12년 (SPC 포함) |
| 특허 유형 | 물질 특허 또는 용도 특허 | 물질 + 제법 + 용도 복합 포트폴리오 |
| FTO 상태 | 주요 시장 (US/EU/JP/KR) FTO 확인 | 글로벌 FTO 확인 |
| 데이터 독점 | NCE 5년 (미국) 또는 8+2년 (EU) | Orphan 7년 + NCE 중복 적용 |
| 라이센싱 부담 | 로열티 < 8% (순매출) | 로열티 < 3% 또는 무로열티 |
| 제네릭 진입 장벽 | 합성 복잡도 + 특허 | 바이오의약품 수준 진입 장벽 |

**Filter 연결**:
- Layer 6 IP (FTO, 특허 출원 가능성, 잔여 기간) → IP 보호 MAP
- Layer 6 라이센싱 (로열티 추정) → 상업화 요건 MAP

---

## Section 7. 시장·규제 요건

| 항목 | Minimum Acceptable | Optimal |
|---|---|---|
| 규제 경로 | 표준 NDA/BLA (10~12개월 심사) | Fast Track + Priority Review (6개월) |
| 허가 시장 | 미국 또는 EU (1개 주요 시장) | 미국 + EU + JP 동시 허가 |
| 임상 개발 기간 | Phase 1~3 총 8~10년 | 가속 승인 경로 활용 5~7년 |
| 약가 포지셔닝 | ICER < $150,000/QALY (미국) | 프리미엄 약가 + 성과 기반 계약 |
| 보험 급여 | 미국 주요 보험사 커버리지 | 글로벌 주요 시장 1차 급여 |
| Peak Sales 목표 | > $500M/년 (블록버스터 기준 하한) | > $1B/년 |
| rNPV | > $0 (양의 기대값) | > $500M |

**Filter 연결**:
- Stage 4 (TAM, rNPV, SoC 차별성) → 시장·규제 MAP 전체

---

## Section 8. 바이오마커 / 동반진단 전략

| 항목 | Minimum Acceptable | Optimal |
|---|---|---|
| 환자 선별 바이오마커 | 반응 예측 바이오마커 1개 이상 확인 | 복수 바이오마커 조합 선별 |
| 바이오마커 측정법 | 조직 기반 (허가 당시) | 혈액 기반 (액체 생검) |
| 동반진단 개발 | 허가 시점 CDx 동시 개발 계획 | 허가 전 CDx 승인 완료 |
| PD 바이오마커 | 타겟 조절 확인 PD 마커 ≥1개 | 다중 PD 마커 패널 |
| 반응자 비율 | 전체 환자의 ≥ 20% | ≥ 50% (또는 전체 환자군) |

**Filter 연결**:
- Layer 8 (PD 바이오마커) → PD 마커 MAP
- Stage 4-A (환자 계층화) → 바이오마커 전략 전체

---

## TPP 수립 프로세스 (단계별)

```
Step 1. Filter 조건 수집
  └─ 11개 Layer 통과 기준 전체 목록화

Step 2. MAP 초안 수립
  └─ 각 Filter 통과 기준의 임상 언어 번역
  └─ No-Go 기준 = MAP 하한값으로 설정

Step 3. OP 설정
  └─ SoC 대비 차별화 목표 정의
  └─ 경쟁 파이프라인 분석 기반 포지셔닝

Step 4. 내부 정렬 (Cross-functional)
  └─ 임상 팀: 효능·안전성 MAP/OP 검토
  └─ CMC 팀: 제조 요건 MAP/OP 검토
  └─ IP 팀: 특허 보호 MAP/OP 검토
  └─ 시장/재무 팀: rNPV 기반 MAP/OP 검토

Step 5. 규제 사전 미팅 반영
  └─ Pre-IND Meeting (FDA) 또는 Scientific Advice (EMA)
  └─ 규제 기관 피드백 → MAP 조정

Step 6. DBTL 루프 연동
  └─ 각 DBTL 사이클 종료 시 TPP 달성 여부 체크
  └─ 미달성 항목 → 다음 Bocheming 최적화 목표로 설정
  └─ 5~10 사이클마다 MAP/OP 재검토
```

---

## TPP ↔ Go/No-Go 의사결정 연동

```
MAP 모두 충족          → Go (다음 개발 단계 진행)
MAP 1~2개 미충족       → Conditional Go (보완 계획 수립 후 진행)
MAP 핵심 항목 미충족   → No-Go (개발 중단 또는 재설계)
OP 50% 이상 달성       → 전략적 우선순위 상향
```

**핵심 MAP 항목 (미충족 시 즉시 No-Go)**
- hERG 관련 QTc 연장 > 20ms
- AMES 양성
- FTO 차단 (회피 불가)
- rNPV < 0 (시장성 부재)
- 타겟 유효성 증거 없음 (OT score < 0.2)

→ 상세 스코어링: `biopharma-gng-decision` 스킬과 연동 사용 권장

---

## TPP 산출물 형식

TPP 수립 요청 시 다음 산출물을 생성한다:

### 1. TPP 요약표 (1페이지)
- 8개 섹션 × MAP/OP 2열 구조
- 섹션별 달성 현황 (Green/Yellow/Red)

### 2. Filter-TPP 매핑 매트릭스
- 각 Virtual Screening Layer → 해당 TPP 섹션 연결
- 현재 후보 물질의 Filter 통과 상태 → TPP 달성 예측

### 3. Gap 분석 보고서
- 현재 후보 물질 프로파일 vs TPP MAP 비교
- Gap 항목별 보완 전략 (재설계 / 제형 최적화 / 추가 실험)

### 4. DBTL 최적화 우선순위
- TPP Gap → Bocheming 다음 사이클 목표로 변환
- 가중치 설정: MAP 미달 항목 우선, OP 달성 목표 차순