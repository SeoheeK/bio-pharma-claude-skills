# 참조 00: 임상 데이터 기반 바이오마커 군집분석 모듈

## 위치 및 목적

**파이프라인 내 위치**: Stage 0 (타겟 선정) 내 Layer TV-A (인과성 검증)의 하위 모듈
**MR 기반 유전적 인과성과의 관계**:

```
MR 기반 인과성 (유전적)          임상 데이터 군집분석 (표현형)
──────────────────────          ──────────────────────────────
"타겟이 질환을 일으키는가"         "타겟이 환자에서 어떤 패턴을 보이는가"
집단 수준, 변이 기반               개인 수준, 발현값 기반
인과 방향 확인                     반응 예측·환자 층화
선천적 배정 활용                   실제 측정값 활용
교란변수 통제                      임상 맥락 반영
```

두 접근법은 **상호 보완**이다. MR이 "왜"를 설명한다면,
임상 군집분석은 "누가, 언제, 어느 정도로"를 설명한다.

---

## 전체 분석 흐름

```
[입력] 타겟 단백질 발현 데이터 + 임상 코호트
         ↓
[Sub-A1] 환자 군집분석 (Patient Clustering)
  · 다차원 발현 데이터로 환자 서브그룹 정의
  · 군집별 임상 표현형 연결
         ↓
[Sub-A2] 바이오마커 순위화 (Biomarker Ranking)
  · 군집 정의 핵심 바이오마커 선별
  · 예측·예후·PD 바이오마커 분류
         ↓
[Sub-A3] 발현 양상 패터닝 (Expression Pattern Analysis)
  · 시간적·공간적·상관·이질성 패턴 분석
         ↓
[출력] → TPP 바이오마커 전략 입력
       → Virtual Screening 반응자 정의
       → 임상 시험 층화 설계 기준
       → Layer TV-E 발현 적합성 정밀화
```

---

## Sub-A1. 환자 군집분석 (Patient Clustering)

**목적**: 타겟 단백질 발현을 포함한 다차원 임상 데이터로 환자를 군집화해
타겟 발현 패턴과 임상 표현형의 연결을 확인한다.

### 군집분석 방법론 선택 기준

| 방법 | 출력 | 적합 상황 | 주의사항 |
|---|---|---|---|
| **계층적 군집분석 (HCA)** | 덴드로그램 | 소규모 코호트, 탐색적 분석 | 노이즈 민감, 확장성 낮음 |
| **k-means / k-medoids** | k개 군집 레이블 | 대규모, 군집 수 가설 있을 때 | 군집 수 사전 지정 필요 |
| **NMF (Non-negative Matrix Factorization)** | 잠재 요인 행렬 | 유전자 발현 행렬, 다중오믹스 | 음수 값 불가 |
| **Consensus Clustering** | 군집 안정성 CDF | 임상 서브타입 최종 정의 | 계산 비용 높음 |
| **UMAP / t-SNE** | 2D 시각화 | 단일세포, 탐색적 패턴 발견 | 거리 보존 불완전 |
| **Gaussian Mixture Model** | 확률적 군집 할당 | 중첩 군집, 불확실성 필요 시 | 수렴 불안정 가능 |
| **Spectral Clustering** | 그래프 기반 군집 | 비선형 경계, 복잡한 구조 | 커널 선택 민감 |
| **Leiden / Louvain** | 커뮤니티 구조 | 단일세포, 네트워크 기반 | 해상도 파라미터 의존 |

### 임상 타겟 벨리데이션 군집분석 실행 흐름

```
Step 1. 데이터 행렬 구성
  · 행: 환자 (샘플)
  · 열: 타겟 단백질 발현 + 공동발현 유전자 + 임상 변수
  · 전처리: 정규화 (z-score / quantile), 결측치 처리, 배치 보정

Step 2. 최적 군집 수 결정
  · Gap statistic (k-means)
  · Consensus CDF 변곡점 (Consensus Clustering)
  · Silhouette score 최대화
  · 생물학적 해석 가능성 검토

Step 3. 군집 실행 및 안정성 검증
  · Bootstrap 재샘플링 (1000회)
  · Cophenetic correlation coefficient > 0.75
  · 독립 코호트에서 재현성 확인

Step 4. 군집별 임상 표현형 비교
  · 생존율: Kaplan-Meier + Log-rank test
  · 치료 반응: Fisher's exact / chi-square
  · 중증도·병기: Kruskal-Wallis + Dunn post-hoc
  · 다변수: Cox proportional hazards

Step 5. 타겟 발현이 군집 정의 핵심 변수인지 확인
  · 군집 간 타겟 발현 fold change (> 2배 선호)
  · 타겟이 군집 정의 상위 10% 변수에 포함되는지
  · 타겟 발현 분위수별 군집 분포 확인
```

### 군집별 임상 표현형 해석 기준

```
강력한 타겟 벨리데이션 신호:
  ✓ 타겟 고발현 군집 vs 저발현 군집 생존율 HR > 1.5 (p < 0.05)
  ✓ 타겟 고발현 군집에서 치료 반응률 ≥ 2배 차이
  ✓ 독립 코호트 3개 이상에서 동일 패턴 재현
  ✓ 다변수 보정 후에도 독립적 예후 인자

경고 신호:
  ✗ 단변수에서만 유의 (다변수 보정 후 소실)
  ✗ 단일 코호트에서만 관찰
  ✗ 타겟이 군집 정의 하위 50% 변수
  ✗ 군집 간 표현형 차이 없음
```

---

## Sub-A2. 바이오마커 순위화 (Biomarker Ranking)

**목적**: 군집분석 결과를 기반으로 어떤 바이오마커가 타겟 발현 패턴과
질환 결과를 가장 잘 연결하는지 순위를 정한다.

### 바이오마커 유형별 분류 및 분석 방법

#### 예측 바이오마커 (Predictive Biomarker)
치료 반응을 사전에 예측하는 바이오마커. 동반진단(CDx) 개발의 기반.

```
분석 방법:
  · 반응군 vs 비반응군 발현 비교 (ROC-AUC > 0.7 목표)
  · 치료 × 바이오마커 상호작용 검정 (interaction p < 0.1)
  · 최적 컷오프 결정 (Youden index, DeLong method)

순위화 알고리즘:
  1. Univariate logistic regression (치료 반응 ~ 각 바이오마커)
  2. LASSO / Elastic Net (다변수 축소 선택)
  3. Random Forest Feature Importance
  4. SHAP value (개별 환자 기여도 분해)
  5. Boruta (안정적 변수 선택)

검증:
  · 교차검증 (5-fold / Leave-One-Out)
  · 독립 검증 코호트 AUC 확인
  · 임상적 유용성: Net Benefit (DCA 곡선)
```

#### 예후 바이오마커 (Prognostic Biomarker)
치료와 무관하게 질환 결과를 예측하는 바이오마커.

```
분석 방법:
  · Cox proportional hazards (다변수)
  · Kaplan-Meier (발현 분위수별 층화)
  · Time-dependent ROC (AUC at t=1,3,5년)

순위화 기준:
  · HR (Hazard Ratio): > 1.5 또는 < 0.67
  · 95% CI 및 p-value
  · C-index 개선 기여도
  · 기존 임상 인자 대비 추가 예측력 (IDI, NRI)
```

#### 약동학 바이오마커 (Pharmacodynamic Biomarker)
타겟 조절 여부를 실시간으로 확인하는 바이오마커.

```
분석 방법:
  · 투여 전→후 발현 변화율
  · 용량-반응 상관 (r² > 0.5)
  · 타겟 점유율과 PD 마커 변화 상관

순위화 기준:
  · 치료 후 발현 변화 > 50% (민감도)
  · 정상 조직에서 변화 < 20% (특이도)
  · 측정 가능성: 혈액 > 조직 > 영상
```

### 바이오마커 순위화 통합 스코어

```
통합 바이오마커 점수 (BMS):

BMS = w1 × Predictive_AUC
    + w2 × Prognostic_HR_score
    + w3 × PD_sensitivity
    + w4 × Reproducibility_score
    + w5 × Measurability_score

가중치 기본값:
  w1 = 0.30 (예측력)
  w2 = 0.25 (예후력)
  w3 = 0.20 (PD 민감도)
  w4 = 0.15 (재현성)
  w5 = 0.10 (측정 가능성)

BMS > 0.7: 강력한 바이오마커 후보
BMS 0.5~0.7: 추가 검증 필요
BMS < 0.5: 보조 바이오마커 수준
```

### 동반 바이오마커 발굴 (Co-biomarker Discovery)

타겟 단독이 아니라 동반 바이오마커 패널로 예측력을 높이는 전략.

```
WGCNA (Weighted Gene Co-expression Network Analysis):
  · 타겟과 높은 상관을 갖는 유전자 모듈 추출
  · 모듈 허브 유전자 = 동반 바이오마커 후보
  · 모듈-임상 표현형 상관 행렬 → 관련 모듈 우선순위화

출력:
  · 타겟 동일 모듈 유전자 리스트
  · 모듈별 임상 연관성 (r, p-value)
  · 바이오마커 패널 구성 제안 (2~5개)
```

---

## Sub-A3. 발현 양상 패터닝 (Expression Pattern Analysis)

**목적**: 단순 발현량이 아니라 시간적·공간적·맥락적 발현 패턴을 분석해
타겟의 질환 내 역할을 입체적으로 이해한다.

### 패턴 유형 1: 시간적 패턴 (Temporal Pattern)

```
분석 대상:
  · 질환 진행 단계에 따른 타겟 발현 궤적
  · 치료 전 → 치료 중 → 치료 후 → 내성 발생 발현 변화
  · 내성 발생 전 발현 전환점 (inflection point)

분석 방법:
  · 종단 혼합 효과 모델 (Linear Mixed Effects Model)
    └─ 시간·개인 간 변이 동시 모델링
  · 궤적 군집분석 (Growth Mixture Model, GMM)
    └─ 다양한 발현 궤적 패턴 그룹 분류
  · 변화점 분석 (Change Point Detection)
    └─ 내성 발생 또는 치료 반응 전환 시점 탐지

임상적 활용:
  · "초기 고발현 → 치료 후 감소 → 내성 시 재상승" 패턴
    → 내성 모니터링 바이오마커로 활용
  · "치료 전 발현 수준이 치료 반응 예측"
    → 예측 바이오마커 컷오프 근거
```

### 패턴 유형 2: 공간적 패턴 (Spatial Pattern)

```
분석 대상:
  · 조직 내 세포 유형별 발현 분포
  · 종양 미세환경(TME) 내 타겟 발현 위치
  · 침윤 경계부(invasive margin) vs 종양 중심부 차이
  · 전이 병소 vs 원발 병소 발현 차이

분석 방법:
  · 공간 전사체학 (10x Visium, Slide-seq, MERFISH)
    └─ 조직 위치 정보 보존한 전사체 분석
  · Spatially Variable Genes (SVGs) 분석
    └─ 공간적으로 유의미한 발현 패턴 유전자 선별
  · 세포-세포 상호작용 분석 (CellChat, NicheNet)
    └─ 타겟 발현 세포와 주변 세포 간 신호 전달

임상적 활용:
  · 타겟이 침윤 경계부에서만 발현
    → 국소 전달 제형 전략 근거
  · TME 내 특정 면역 세포에서 공동발현
    → 병용 면역항암제 전략 가설
```

### 패턴 유형 3: 공동발현 패턴 (Co-expression Pattern)

```
분석 방법:
  · WGCNA: 가중 유전자 공동발현 네트워크
  · SCENIC: 전사인자 조절 네트워크 추론
  · STRING 네트워크 + 발현 데이터 통합

출력:
  · 타겟과 강한 양성 상관 유전자 → 동일 경로, 동반 바이오마커
  · 타겟과 강한 음성 상관 유전자 → 보상 경로, 내성 기전
  · 타겟 조절 전사인자 → 상위 조절자, 추가 타겟 가설
```

### 패턴 유형 4: 이질성 패턴 (Heterogeneity Pattern)

```
분석 대상:
  · 종양 내 이질성 (Intra-tumor heterogeneity, ITH)
  · 단일세포 수준 발현 분포 (bimodal vs unimodal)
  · 희소 발현 세포 서브클론 탐지

분석 방법:
  · 단일세포 RNA-seq (Seurat, Scanpy)
    └─ 세포 유형별 타겟 발현 분포 분석
  · Bimodality index 계산
    └─ BI > 1.1: 두 가지 발현 상태 존재 (on/off)
  · Copy number variation (CNV) 분석 (inferCNV)
    └─ 유전체 이질성과 발현 이질성 연결

임상적 활용:
  · 타겟 발현 bimodal 분포
    → 환자 내 서브클론 존재 → 내성 발생 위험 높음
    → 단일 타겟 치료보다 병용 전략 필요
  · 희소 타겟 음성 서브클론 비율
    → 내성 출현 시간 예측 변수
```

---

## Sub-A4. 핵심 데이터셋·도구 전체 목록

### 임상 코호트 데이터셋

| 데이터셋 | 내용 | 규모 | 접근 |
|---|---|---|---|
| **TCGA** | 33개 암종 멀티오믹스 (RNA, DNA, 단백질) + 임상 | 11,000+ 환자 | gdc.cancer.gov |
| **ICGC** | 국제 암 유전체 컨소시엄 | 22,000+ 종양 | icgc.org |
| **CPTAC** | 단백질체 + 유전체 통합 임상 코호트 | 1,000+ 환자 | proteomics.cancer.gov |
| **GEO** | 질환 vs 정상 DEG 데이터 수천 건 | 5,000,000+ 샘플 | ncbi.nlm.nih.gov/geo |
| **ArrayExpress** | 기능 유전체학 실험 데이터 | 공개 | ebi.ac.uk/arrayexpress |
| **UK Biobank** | 50만 명 코호트, 멀티오믹스 연계 | 500,000+ | ukbiobank.ac.uk |

### 단일세포·공간 전사체 데이터셋

| 데이터셋 | 내용 | 규모 | 접근 |
|---|---|---|---|
| **CELLxGENE** | 단일세포 전사체 통합 아틀라스 | 50M+ 세포 | cellxgene.cziscience.com |
| **TISCH (Tumor Immune SC Hub)** | 종양 단일세포 전사체 DB, TME 포함 | 2,000,000+ 세포 | tisch.comp-genomics.org |
| **Human Cell Atlas** | 전체 인체 세포 유형 지도 | 공개 | humancellatlas.org |
| **PanglaoDB** | 세포 유형 마커 유전자 DB | 8,000+ 마커 셋 | panglaodb.se |
| **10x Genomics Public Datasets** | 공간 전사체 + scRNA-seq 샘플 | 공개 | 10xgenomics.com |

### 단백질체 데이터셋

| 데이터셋 | 내용 | 접근 |
|---|---|---|
| **CPTAC Proteomics** | 임상 단백질체학, 치료 반응 연계 | proteomics.cancer.gov |
| **Human Proteome Map** | 30개 조직 단백질체 | humanproteomemap.org |
| **ProteomicsDB** | 조직·세포주 단백질 발현 | proteomicsdb.org |
| **PhosphoSitePlus** | 인산화 등 번역 후 변형 데이터 | phosphosite.org |

### 생존·예후 분석 도구

| 도구 | 기능 | 접근 |
|---|---|---|
| **KM-Plotter** | 유전자 발현 vs 생존율 자동 분석 (유방암·폐암·대장암·위암) | kmplot.com |
| **TIMER2.0** | 암 면역 침윤 + 발현 예후 통합 분석 | timer.cistrome.org |
| **PrognoScan** | 다중 코호트 예후 메타분석 | prognoscan.org |
| **GEPIA2** | TCGA 기반 발현·생존 분석 웹 인터페이스 | gepia2.cancer-pku.cn |
| **OncoLnc** | TCGA 생존 분석 + 유전자 발현 연계 | oncolnc.org |

### 군집분석·바이오마커 통합 분석 도구

| 도구 | 기능 | 유형 |
|---|---|---|
| **cBioPortal** | 임상 데이터 + 유전체 통합 탐색, 군집별 생존 비교 | 웹 + R/Python API |
| **LinkedOmics** | TCGA 멀티오믹스 바이오마커 연관 분석 | 웹 |
| **ConsensusClusterPlus** | 임상 서브타입 군집 안정성 평가 | R 패키지 |
| **WGCNA** | 가중 유전자 공동발현 네트워크 | R 패키지 |
| **Seurat** | 단일세포 분석 파이프라인 (군집, UMAP, DEG) | R 패키지 |
| **Scanpy** | Seurat Python 버전 | Python |
| **SCENIC** | 전사인자 조절 네트워크 추론 | R/Python |
| **CellChat / NicheNet** | 세포-세포 상호작용 신호 분석 | R 패키지 |
| **inferCNV** | 단일세포 CNV 분석 (종양 클론 구조) | R 패키지 |

### 바이오마커 순위화 도구

| 도구 | 기능 | 유형 |
|---|---|---|
| **SHAP** | 개별 샘플별 바이오마커 기여도 분해 | Python |
| **Boruta** | 안정적 변수 선택 (Random Forest 기반) | R/Python |
| **glmnet** | LASSO / Elastic Net 다변수 선택 | R |
| **survcomp** | 생존 분석 기반 바이오마커 평가 (C-index, IDI, NRI) | R |
| **timeROC** | 시간 의존적 ROC 분석 | R |
| **rmda** | Decision Curve Analysis (Net Benefit) | R |

---

## Sub-A5. 분석 결과 → 하위 모듈 연결 매핑

군집분석 및 패터닝 결과가 파이프라인 내 어디로 연결되는지 명시한다.

```
군집분석 결과물                    연결 대상
─────────────────────────         ───────────────────────────
환자 서브타입 정의              →  TPP Section 1 (적응증·환자군)
                                →  TPP Section 8 (바이오마커·CDx 전략)

예측 바이오마커 순위            →  TPP Section 8 (동반진단 개발)
                                →  Layer 8 (질환 유효성) 강화
                                →  임상 1상 층화 설계 기준

예후 바이오마커 순위            →  TPP Section 2 (효능 목표 설정)
                                →  Stage 4-A (환자 계층화 전략)

PD 바이오마커 후보              →  DBTL T 단계 측정 지표 설정
                                →  Bocheming 보상 함수 PD 항목

발현 이질성 패턴                →  Layer 10 (내성 기전 예측)
                                →  REINVENT 보상 함수 선택성 항목

시간적 발현 궤적                →  TPP Section 4 (PK/PD 프로파일)
                                →  임상 샘플링 시점 설계

공간적 발현 패턴                →  TPP Section 1 (타겟 조직 특이성)
                                →  MSAT Layer 5 (제형화 전략)
```

---

## Sub-A6. 타겟 벨리데이션 통합 스코어카드

MR 기반 유전적 인과성(Layer TV-A)과 임상 군집분석(이 모듈)을 통합해
타겟 벨리데이션 종합 점수를 산출한다.

```
타겟 벨리데이션 통합 점수 (TVS):

TVS = A_genetic × 0.30    # MR 기반 인과성
    + A_clinical × 0.25   # 임상 군집분석 (이 모듈)
    + B_druggable × 0.20  # 드러거빌리티
    + C_essential × 0.10  # DepMap 필수성
    + D_safety × 0.10     # 안전성
    + E_expression × 0.05 # 발현 적합성

A_clinical 세부 점수:
  · 군집별 생존율 HR 유의: 0.0~0.4
  · 바이오마커 예측 AUC > 0.7: 0.0~0.3
  · 3개 이상 독립 코호트 재현: 0.0~0.3

TVS 판정:
  ≥ 0.7:  강력한 타겟 (Stage 1 진입 허가)
  0.5~0.7: 조건부 타겟 (보완 실험 후 재평가)
  < 0.5:  타겟 재선정 권고
```