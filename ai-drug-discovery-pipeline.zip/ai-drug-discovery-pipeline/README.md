# AI Drug Discovery Pipeline — README

**스킬명**: ai-drug-discovery-pipeline
**버전**: v1.3
**최종 업데이트**: 2026.06

---

## 이 스킬이 하는 일

Evo2, AlphaFold3, REINVENT, Bocheming, Benchiling, SDL을 통합한
**AI-Native End-to-End 신약 발굴 파이프라인**을 설계·평가·산출한다.

Virtual Screening 필터 설계, DBTL 루프 구축, TPP 수립,
타겟 벨리데이션 모델·데이터셋 선택, 임상 번역·시장성 분석까지
신약 후보물질이 아이디어에서 IND 신청까지 가는 전 과정을 커버한다.

---

## 전체 파이프라인 플로우

```
┌─────────────────────────────────────────────────────────────────┐
│                    PRE-STAGE: 타겟 선정                          │
│                                                                  │
│  임상 데이터 군집분석 → 유전적 인과성(MR) → 드러거빌리티 → 필수성  │
│  → 발현 적합성 → 안전성 → 타겟 벨리데이션 통합 점수(TVS) 산출     │
└─────────────────────────────┬───────────────────────────────────┘
                              │ TVS ≥ 0.7 → 진입 허가
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    STAGE 1: AI 분자 생성                         │
│                                                                  │
│  Evo2 (서열 설계)                                                │
│    → AlphaFold3 (구조·결합 포즈 예측)                            │
│    → REINVENT (소분자 de novo 생성, 다목적 보상 함수)             │
│    → Bocheming (GP Surrogate로 탐색 공간 효율화)                 │
└─────────────────────────────┬───────────────────────────────────┘
                              │ 수만 개 후보 분자
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                STAGE 2: VIRTUAL SCREENING (11 Layers)            │
│                                                                  │
│  Layer 0    PAINS / Brenk 제거              (sub-second)         │
│  Layer 0.5  타겟 유효성 사전 확인            (사전 확립)           │
│  Layer 1    물리화학적 필터                   (초)                │
│  Layer 2    합성 가능성 (MSAT)               (초~분)              │
│  Layer 3    화학적 안정성 (MSAT)             (분)                 │
│  Layer 4    ADMET 예측                       (분)                │
│  Layer 5    제형화 가능성 (MSAT)             (분)                 │
│  Layer 6    IP / FTO 스크리닝               (분~반자동)           │
│  Layer 7    도킹 / AlphaFold3 구조 기반     (시간)               │
│  Layer 8    질환 유효성 / 타겟 적합성        (전문가 검토)         │
│  Layer 9    선택성 / 오프타겟 프로파일링     (시간~일)             │
│  Layer 10   내성 기전 예측                   (전문가 검토)         │
│  Layer 11   스케일업·분석 가능성 (MSAT)     (전문가 검토)         │
└─────────────────────────────┬───────────────────────────────────┘
                              │ 수십~수백 개 후보
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                  STAGE 2.5: TPP 수립                             │
│                                                                  │
│  Filter 조건 → 임상·규제·시장 언어 번역                           │
│  MAP (Minimum Acceptable Profile) / OP (Optimal Profile) 정의    │
│  8개 섹션: 적응증 / 효능 / 안전성 / PK·PD / CMC / IP / 시장 / CDx│
└─────────────────────────────┬───────────────────────────────────┘
                              │ TPP Gap → 최적화 목표 설정
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                  STAGE 3: DBTL 검증 루프                         │
│                                                                  │
│  [D] Bocheming → 다음 실험 조건 n개 추천 (Batch BO)              │
│       ↓ API 자동 전송                                             │
│  [B] SDL → 자율 합성 (로봇 액체처리, DNA 어셈블리, 배양)           │
│       ↓ 샘플 자동 이송                                            │
│  [T] SDL + Benchiling → 자율 측정 (HTS, LC-MS, SPR)             │
│       ↓ 구조화 데이터 자동 반환                                    │
│  [L] Bocheming → GP Posterior 갱신, 다음 D 트리거                │
│                                                                  │
│  목표 사이클 타임: 24~72시간/회전                                  │
└─────────────────────────────┬───────────────────────────────────┘
                              │ 검증된 리드 후보
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                STAGE 4: 번역·의사결정                             │
│                                                                  │
│  4-A 환자 계층화 / 바이오마커 전략                                 │
│  4-B 임상 개발 가능성 (SoC 차별성, 규제 경로, 1상 설계)            │
│  4-C 경제성 / 시장성 (rNPV, TAM, 경쟁 파이프라인)                 │
│  4-D ESG / 윤리 (3R, 그린케미스트리, AI 책임)                     │
│                                                                  │
│  → Go/No-Go 의사결정 → IND 신청 후보 확정                         │
└─────────────────────────────────────────────────────────────────┘
```

---

## 각 단계 상세 소개

### PRE-STAGE. 타겟 선정 & 질환 생물학 확립

**목적**: 잘못된 타겟에 투자하는 신약 개발 최대 실패 원인을 사전 차단.

**두 축의 병렬 검증**

```
축 1. 임상 데이터 기반 군집분석 (00-clinical-biomarker-clustering.md)
  · 환자 군집분석으로 타겟 발현 패턴과 임상 표현형 연결 확인
  · 바이오마커 순위화 (예측·예후·PD 바이오마커 분류)
  · 시간적·공간적·이질성 발현 패턴 분석
  · 출력 → TVS의 A_clinical 점수

축 2. 유전적 인과성 + 5개 벨리데이션 Layer (01-target-disease-validation.md)
  · TV-A 인과성: MR-Base, TwoSampleMR, UK Biobank pQTL
  · TV-B 드러거빌리티: fpocket, PocketDTA, PDBbind
  · TV-C 필수성: DepMap Chronos Score, Project Score
  · TV-D 안전성: OpenTargets Safety, gnomAD pLI
  · TV-E 발현 적합성: GTEx, Human Protein Atlas, CELLxGENE
  · 출력 → TVS 종합 점수
```

**TVS(타겟 벨리데이션 통합 점수) ≥ 0.7**: Stage 1 진입 허가
**TVS < 0.5**: 타겟 재선정

---

### STAGE 1. AI 분자 생성 (02-ai-generation-tools.md)

**목적**: 타겟 구조와 질환 생물학에 최적화된 후보 분자를 AI로 대규모 생성.

**도구 연결 흐름**

| 단계 | 도구 | 입력 | 출력 |
|---|---|---|---|
| 서열 설계 | **Evo2** | 타겟 단백질 서열 | 변이체 효과 점수, 기능성 서열 |
| 구조 예측 | **AlphaFold3** | Evo2 출력 서열 + 리간드 SMILES | PDB 구조, 결합 포즈 (pLDDT≥70) |
| 분자 생성 | **REINVENT 4** | 결합 포켓 정보, 보상 함수 | SMILES 후보 라이브러리 |
| 탐색 최적화 | **Bocheming** | 실험 피드백, 특성 공간 | 다음 실험 후보 + 불확실성 |

**REINVENT 보상 함수**: 결합 친화도 + ADMET + MSAT + IP 패널티 + 유효성 + 선택성 7항목 가중합

---

### STAGE 2. Virtual Screening — 11개 Layer 깔때기 (03-virtual-screening-filters.md)

**목적**: 수만 개 AI 생성 분자에서 실제로 개발 가능한 리드 후보를 선별.

**설계 원칙**: 계산 비용 낮은 것 → 높은 것 순. 각 Layer 통과율은 10~30%.

**필터 범위 설정 3가지 소스**
1. 임상 성공 분자 역추적 (동일 타겟 임상 2상+ 통과 분자의 5~95 퍼센타일)
2. 표적·적응증 특이적 조정 (투여 경로, 환자군 특성 반영)
3. Bocheming DBTL 루프 데이터 기반 주기적 업데이트

**주요 Layer별 핵심 변수**

| Layer | 카테고리 | 핵심 변수 | 탈락 비율 |
|---|---|---|---|
| 0 | 구조 경고 | PAINS 480패턴, Brenk 105패턴 | ~20% |
| 1 | 물리화학 | MW, cLogP, HBD, HBA, TPSA | ~30% |
| 2 | MSAT 합성 | SA Score ≤3.5, 단계 수 ≤8, 빌딩블록 가용성 | ~20% |
| 3 | MSAT 안정성 | 가수분해·산화·광분해 안정성 구조 패턴 | ~10% |
| 4 | ADMET | hERG, AMES, Caco-2, CYP, BBB | ~30% |
| 5 | MSAT 제형 | 용해도, BCS 분류, pH 프로파일 | ~10% |
| 6 | IP/FTO | SureChEMBL Tanimoto < 0.85, Markush 범위 외 | ~15% |
| 7 | 구조 기반 | 도킹 상위 5~10%, pLDDT≥70 | ~70% |
| 8 | 질환 유효성 | MoA 일치, PD 마커 조절, TI > 10 | ~30% |
| 9 | 선택성 | 선택성 지수 ≥100배, GPCR/키나제 패널 | ~20% |
| 10 | 내성 | 돌연변이 내성 위험, 유출 펌프 기질 | ~10% |
| 11 | MSAT 스케일업 | 발열 위험, 독성 시약, 분석 가능성 | ~10% |

---

### STAGE 2.5. TPP 수립 (06-tpp-framework.md)

**목적**: Virtual Screening 필터 조건을 임상·규제·시장 언어로 번역해
DBTL 루프의 최적화 목표를 명확히 정의.

**Filter → TPP 변환 원칙**
- Filter: "이 분자가 이 기준을 충족 못 하면 제거"
- TPP: "최종 제품이 이 기준을 반드시 갖춰야 함"

**TPP 8개 섹션**

| 섹션 | 핵심 내용 | 연결 Filter Layer |
|---|---|---|
| 1. 적응증·환자군 | 질환 범위, 환자 수, 바이오마커 선별 | PRE-STAGE 군집분석 |
| 2. 임상 효능 목표 | SoC 대비 개선폭, ORR, DoR | Layer 8 유효성 |
| 3. 안전성 프로파일 | QTc, Grade≥3 AE 비율, 간·신 독성 | Layer 4, 9 |
| 4. PK/PD 프로파일 | 투여 경로, t½, 생체이용률, 타겟 점유율 | Layer 1, 4 |
| 5. CMC·제조 요건 | 합성 단계, 배치 순도, 보관 안정성 | Layer 2, 3, 11 |
| 6. IP·상업화 요건 | 특허 잔여 기간, FTO, 로열티 | Layer 6 |
| 7. 시장·규제 요건 | 규제 경로, 약가, rNPV | Stage 4 |
| 8. 바이오마커·CDx | PD 마커, 동반진단 계획 | PRE-STAGE 군집분석 |

**TPP Gap → DBTL 피드백**: MAP 미달 항목이 Bocheming 다음 사이클 목표로 자동 전환

---

### STAGE 3. DBTL 검증 루프 (04-dbtl-loop-design.md)

**목적**: Virtual Screening 통과 후보를 자동화 실험으로 신속 검증·최적화.

**세 요소 역할**

| 요소 | DBTL 위치 | 핵심 역할 |
|---|---|---|
| **Benchiling** | T+L 허브 | ELN, 프로토콜 버전 관리, 기기 API 직결, 샘플 계보 추적 |
| **SDL** | B+T 실행 | 자율 합성(Hamilton/Opentrons), 자율 측정(HTS/LC-MS/SPR) |
| **Bocheming** | D+L 최적화 | GP Surrogate 업데이트, Batch BO 다음 실험 추천 |

**핵심 설계 결정 4가지**
1. Inner(REINVENT RL) vs Outer(Bocheming BO) 루프 교차 방식
2. Benchiling ↔ SDL ↔ Bocheming 인터페이스 미들웨어 설계
3. 노이즈 모델링 및 이상치 필터링 파이프라인
4. 필터 범위 메타 업데이트 주기 (5~10 사이클 또는 데이터 100개 누적)

**전통 vs SDL 통합 DBTL 비교**

| 차원 | 전통 | SDL 통합 |
|---|---|---|
| 사이클 시간 | 2~4주 | 24~72시간 |
| 병렬 실험 | 10~50개 | 수백~수천 개 |
| 재현성 | CV 10~30% | CV 1~5% |

---

### STAGE 4. 번역·의사결정 (05-translation-decision.md)

**목적**: 검증된 리드 후보가 실제로 환자에게 도달할 수 있는지 종합 평가.

**4개 서브 모듈**

**4-A 환자 계층화 / 바이오마커 전략**
PRE-STAGE 군집분석 결과를 임상 설계로 번역.
예측 바이오마커 → CDx 개발, 반응자 비율 추정, 임상 층화 기준.

**4-B 임상 개발 가능성**
SoC 대비 차별화 정의 (효능·안전·편의·비용).
규제 경로 선택 (Fast Track / Breakthrough / Orphan Drug).
임상 1상 시작 용량 추정 (NOAEL × 1/10 또는 MABEL 기반).

**4-C 경제성 / 시장성**
rNPV = Σ[현금흐름 × 임상성공률] / (1+r)^t - 개발비용.
TAM, 경쟁 파이프라인, COGS, 로열티 부담, 보험 급여 가능성.

**4-D ESG / 윤리**
3R 원칙, 그린케미스트리, AI 생성 분자 책임 소재,
접근성·약가 형평성. 현재 규제 공백 영역.

**Go/No-Go 의사결정**: `biopharma-gng-decision` 스킬과 연동 권장.

---

## 참조 파일 전체 목록 및 읽어야 할 때

| 파일 | 내용 요약 | 언제 읽는가 |
|---|---|---|
| `00-clinical-biomarker-clustering.md` | 임상 데이터 기반 환자 군집분석, 바이오마커 순위화, 발현 패터닝 (Sub-A1~A6) | 타겟 인과성 임상 검증, 바이오마커 전략 설계 |
| `01-target-disease-validation.md` | 타겟 유효성 변수 (Module A~D) + 벨리데이션 모델·데이터셋 5개 Layer (Module E) | 타겟 선정, 벨리데이션 모델·데이터셋 선택 |
| `02-ai-generation-tools.md` | Evo2/AF3/REINVENT/Bocheming 상세 설정, 보상 함수, 한계 | AI 분자 생성 도구 통합 설계 |
| `03-virtual-screening-filters.md` | 11개 Layer 전체 변수·범위·데이터소스 (03-A~G) | 필터 설계, 범위 설정, Layer별 상세 |
| `04-dbtl-loop-design.md` | DBTL+Benchiling+SDL 루프 상세, 인터페이스 설계, 구현 현황 | 자동화 실험 루프 설계 |
| `05-translation-decision.md` | 임상 번역·시장성·ESG 변수, rNPV 계산, 규제 경로, Go/No-Go 매트릭스 | Stage 4 의사결정 |
| `06-tpp-framework.md` | TPP 8개 섹션 MAP/OP, Filter→TPP 변환, 수립 프로세스, 산출물 형식 | TPP 수립, Gap 분석 |

---

## 연동 스킬

| 스킬 | 연동 지점 |
|---|---|
| `biopharma-gng-decision` | Stage 4 Go/No-Go 스코어카드 생성 |
| `pk-allometry-ensemble` | Stage 4-B 임상 1상 시작 용량 추정 |
| `pk-biomarker-db` | Stage 2 Layer 8 PD 바이오마커 추천 |
| `pk-popk-modeling-engine` | Stage 4 PK/PD 모델링 |
| `bio-regulatory-analysis` | Stage 4-B 규제 경로 분석 |

---

## 빠른 참조: 질문 유형별 읽어야 할 파일

```
"타겟 벨리데이션 어떻게 해?"
  → 00 (군집분석) + 01 (벨리데이션 모델)

"Virtual Screening 필터 어떻게 설계해?"
  → 03 (필터 전체) + 06 (TPP로 변환)

"DBTL 루프 어떻게 구축해?"
  → 04 (DBTL 설계)

"TPP 작성해줘"
  → 06 (TPP 프레임워크) + 05 (시장성 변수)

"임상 가능성 평가해줘"
  → 05 (번역·의사결정) + 06 (TPP Gap)

"AI 도구 연결 어떻게 해?"
  → 02 (AI 도구 통합)

"전체 파이프라인 설계해줘"
  → README (전체 흐름) → 관련 참조 파일 순차 로드
```

---

## 핵심 원칙 요약

```
원칙 1. 깔때기 구조
  계산 비용 낮은 필터 먼저 → 후보 수 줄인 뒤 비싼 계산 적용

원칙 2. 필터는 학습 대상
  DBTL 루프 누적 데이터로 필터 범위 주기적 업데이트

원칙 3. 유효성이 최우선
  타겟·질환 유효성 없으면 이후 모든 필터가 무의미
  TVS < 0.5면 Stage 1 진입 불가

원칙 4. Discovery-Development 통합
  IP, MSAT, 임상 번역을 Discovery 단계에서 사전 고려

원칙 5. 임상 인과성의 두 축 병렬 검증
  유전적 MR 인과성 + 임상 군집분석 패터닝을 동시에 확인
  둘 중 하나만으로는 타겟 벨리데이션 불완전
```
