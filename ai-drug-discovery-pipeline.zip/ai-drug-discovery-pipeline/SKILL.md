---
name: ai-drug-discovery-pipeline
description: >-
  AI 기반 신약 발굴 통합 파이프라인 프레임워크 (5단계: 타겟 선정 → AI 분자 생성 → Virtual
  Screening → TPP 수립 → DBTL 검증 → 번역·의사결정). Evo2·AlphaFold3·REINVENT·Bocheming
  분자 생성 흐름, 11-Layer 가상 스크리닝 깔때기 필터(PAINS/물리화학/MSAT/ADMET/IP/도킹/선택성),
  타겟·질환 유효성 변수(OpenTargets·MR·DepMap·GTEx), TPP(MAP/OP), Go/No-Go 의사결정
  매트릭스, rNPV·시장성·ESG 변수, 근거 논문 DB를 담은 구조화된 참조 스킬. 다음 요청에 사용:
  "신약 파이프라인", "타겟 선정 워크플로우", "가상 스크리닝 필터 기준", "REINVENT 보상 함수",
  "TPP 수립", "타겟 유효성 검증", "DBTL 루프 설계", "Go/No-Go 결정", "ADMET 컷오프",
  "drug discovery pipeline", "virtual screening cutoffs", "target validation",
  "target product profile", "de novo molecule generation". 신약 개발 단계·필터 임계값·의사결정
  기준·근거 문헌을 조회하거나 특정 타겟/질환에 파이프라인을 적용할 때 트리거.
---

---

## 참조 문서 (references/)

이 스킬은 5단계 파이프라인 개요(아래)와 8개 상세 참조 문서로 구성된다. 특정 Stage·Layer의
상세 변수·임계값·근거가 필요하면 해당 참조 문서를 읽는다.

| 참조 | 파일 | 내용 | 연결 Stage |
|---|---|---|---|
| 00 | `references/00-clinical-biomarker-clustering.md` | 임상 바이오마커 군집분석 (환자 군집화·바이오마커 순위화·발현 패터닝) | Stage 0 (TV-A 하위) |
| 01 | `references/01-target-disease-validation.md` | 타겟·질환 유효성 변수 전체 (Module A~D + 벨리데이션 지도 TV-A~E) | Stage 0 |
| 02 | `references/02-ai-generation-tools.md` | AI 분자 생성 도구 상세 (Evo2·AlphaFold3·REINVENT 4·Bocheming) | Stage 1 |
| 03 | `references/03-virtual-screening-filters.md` | 11-Layer 가상 스크리닝 필터 변수·범위 | Stage 2 |
| 04 | `references/04-dbtl-loop-design.md` | DBTL 검증 루프 설계 (Benchiling + SDL + Bocheming) | Stage 3 |
| 05 | `references/05-translation-decision.md` | 번역·의사결정 변수 + Go/No-Go 매트릭스 | Stage 4 |
| 06 | `references/06-tpp-framework.md` | TPP(Target Product Profile) 수립 프레임워크 (MAP/OP 8개 섹션) | Stage 2.5 |
| 07 | `references/07-filter-evidence-db.md` | 가상 스크리닝 필터 조건 근거 논문 DB (PubMed PMID/DOI 매핑) | Stage 2 근거 |

> **사용 원칙**: 이 프레임워크의 임계값·변수는 참조용 기준선이다. 특정 타겟·적응증·투여
> 경로에 적용할 때는 참조 03의 "필터 범위 설정 3가지 소스"에 따라 조정하고, 실제 데이터
> 조회(OpenTargets, ChEMBL, GTEx 등)로 검증한다.

---

## 파이프라인 개요

전체 파이프라인 구조 (5단계)

[Stage 0]  사전 단계: 타겟 선정 & 질환 생물학 확립
     ↓
[Stage 1]  AI 분자 생성: Evo2 → AlphaFold3 → REINVENT → Bocheming
     ↓
[Stage 2]  Virtual Screening: 11개 Layer 깔때기 필터
     ↓
[Stage 2.5] ★ TPP 수립: Filter 조건 → 임상·규제·시장 언어 번역
     ↓
[Stage 3]  DBTL 검증 루프: Benchiling + SDL + Bocheming
     ↓
[Stage 4]  번역·의사결정: 임상 개발 가능성 + 시장성 + ESG

Stage 0. 사전 단계: 타겟 선정 & 질환 생물학
이 단계 없이 Stage 1을 시작하면 안 된다.
체크리스트
* 타겟 단백질의 유전적 질환 연관성 확인 (OpenTargets score > 0.5)
* MoA 방향성 확립 (억제/활성화/분해 중 무엇이 치료적인가)
* 경쟁 파이프라인 현황 파악 (동일 타겟 임상 단계)
* 시장 규모 및 미충족 의료 수요 사전 확인
* 표준 치료(SoC) 대비 차별화 가설 수립
→ 임상 군집분석·바이오마커 패터닝: references/00-clinical-biomarker-clustering.md 참조 → 상세 변수 + 벨리데이션 모델·데이터셋 전체 지도: references/01-target-disease-validation.md 참조
* Module A~D: 타겟·질환 유효성 변수
* Module E (신규): 5개 Layer 벨리데이션 모델·데이터셋 · TV-A 인과성: MR-Base, TwoSampleMR, Coloc, UK Biobank pQTL · TV-B 드러거빌리티: fpocket, PocketDTA, EMPDTA, PDBbind · TV-C 필수성: DepMap (Chronos Score), Project Score · TV-D 안전성: OpenTargets Safety, TDC, gnomAD pLI · TV-E 발현 적합성: GTEx, Human Protein Atlas, CELLxGENE, TCGA

Stage 1. AI 분자 생성 도구 통합
도구별 역할
도구	DBTL 위치	핵심 기능	TRL
Evo2	Design	서열 생성·변이체 효과 예측·기능성 서열 탐색	4~5
AlphaFold3	Design	단백질-리간드 복합체 3D 구조 예측	7~8
REINVENT 4	Design	RL 기반 소분자 de novo 생성·최적화	6~7
Bocheming	Design + Learn	베이즈 최적화로 다음 실험 조건 결정	5~6
연결 흐름

Evo2 (서열 설계·기능 예측)
  → AlphaFold3 (구조·결합 포즈 예측, pLDDT≥70, ipTM≥0.5)
  → REINVENT (포켓 정보 기반 소분자 생성, 다목적 보상 함수)
  → Bocheming (GP Surrogate로 탐색 공간 효율화)
REINVENT 보상 함수 설계 원칙

python
reward = (
    w1 * binding_affinity_score    # 결합 친화도
  + w2 * admet_score               # ADMET 통과율
  + w3 * msat_score                # 제조 가능성
  - w4 * patent_similarity_score   # 특허 유사도 (패널티)
  + w5 * novelty_score             # 구조 신규성
  + w6 * selectivity_score         # 선택성
  + w7 * efficacy_proxy_score      # 유효성 대리 지표
)
→ 상세 설정: references/02-ai-generation-tools.md 참조

Stage 2. Virtual Screening — 11개 Layer 깔때기 필터
순서가 중요하다. 계산 비용 낮은 것 → 높은 것 순.

Layer 0    PAINS / Brenk 제거              (sub-second)
Layer 0.5  타겟 유효성 사전 확인           (사전 확립)
Layer 1    물리화학적 필터                  (초)
Layer 2    합성 가능성 (MSAT)              (초~분)
Layer 3    화학적 안정성 (MSAT)            (분)
Layer 4    ADMET 예측                      (분)
Layer 5    제형화 가능성 (MSAT)            (분)
Layer 6    IP / FTO 스크리닝              (분~반자동)
Layer 7    도킹 / AlphaFold3 구조 기반    (시간)
Layer 8    질환 유효성 / 타겟 적합성       (전문가 검토)
Layer 9    선택성 / 오프타겟 프로파일링    (시간~일)
Layer 10   내성 기전 예측                  (전문가 검토)
Layer 11   스케일업·분석 가능성 (MSAT)    (전문가 검토)
각 Layer 상세
→ references/03-virtual-screening-filters.md 참조
* 03-A: 물리화학·구조 필터 (Layer 0~1)
* 03-B: MSAT 제조 가능성 필터 (Layer 2~3, 5, 11)
* 03-C: ADMET 필터 (Layer 4)
* 03-D: IP·특허 필터 (Layer 6)
* 03-E: 구조 기반 필터 (Layer 7)
* 03-F: 유효성 필터 (Layer 8)
* 03-G: 선택성·내성 필터 (Layer 9~10)

Stage 3. DBTL 검증 루프 (Benchiling + SDL + Bocheming)
세 요소의 역할
요소	DBTL 위치	핵심 기능
Benchiling	T + L 허브	ELN, 프로토콜 버전 관리, 기기 API 연동, 데이터 구조화
SDL	B + T 실행	자율 합성·측정·스크리닝 자동화
Bocheming	D + L 최적화	GP Surrogate 업데이트, 다음 실험 조건 추천
루프 사이클 (목표: 24~72시간/회전)

[D] Bocheming → 다음 실험 조건 n개 추천 (Batch BO)
  ↓ API 자동 전송
[B] SDL → 자율 합성 (로봇 액체처리, DNA 어셈블리, 배양)
  ↓ 샘플 자동 이송
[T] SDL + Benchiling → 자율 측정 (HTS, LC-MS, SPR)
  ↓ 구조화 데이터 자동 반환
[L] Bocheming → GP Posterior 갱신, 다음 D 트리거
핵심 설계 결정사항
* Inner loop (REINVENT RL) vs Outer loop (Bocheming BO) 교차 방식
* Benchiling ↔ SDL ↔ Bocheming 인터페이스 미들웨어 설계
* 노이즈 모델링 및 이상치 필터링 파이프라인
* Negative Data(실패 실험) 학습 활용 전략
→ 상세 설계: references/04-dbtl-loop-design.md 참조

Stage 4. 번역·의사결정
4-A. 환자 계층화 / 바이오마커 전략
* 예측 바이오마커 (반응자/비반응자 구분)
* PD 바이오마커 (타겟 조절 측정)
* 동반진단 개발 가능성
* 환자 서브타입별 타겟 발현 차이
4-B. 임상 개발 가능성
* SoC 대비 차별성 정의
* 규제 경로 (NDA/BLA/Fast Track/Orphan Drug)
* 임상 1상 시작 용량 추정 (DLT 예측)
* 임상 평가변수 설정 가능성
4-C. 경제성 / 시장성 분석
* TAM, 미충족 의료 수요
* 경쟁 파이프라인 현황
* rNPV 추정 (임상 성공률 × 시장 × 이익률 × 로열티)
* 보험 급여 가능성 (HTA)
4-D. ESG / 윤리 검토
* 3R 원칙 (동물 실험 최소화)
* 그린케미스트리 (합성 환경 부하)
* AI 생성 분자의 책임 소재
* 접근성 / 약가 형평성
→ 상세 변수: references/05-translation-decision.md 참조
